package business_layer;

import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import data_layer.ArrayList_Data;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.print.attribute.IntegerSyntax;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JRadioButton;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JComboBox;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JCheckBox;
import java.awt.Component;



import presentation_layer.Confirmation;
public class Cart extends JFrame {

	private JPanel Option;
	private JTextField txtTo;
	//static String dep="null";
	//static String temp="iqra";
	private JTextField departure;
	private JTextField Entering_Data;
	private JTextField textField;
	String temp1;
	String temp2;
	String temp3;
	String Duration;
	
	int total = 0;
	String D;
	String D2;
	
	private JTextField txtTotalSeat;
	private JTextField txtTotalAmount;
	private JTextField txtTax;
	private JTextField txtGrandTotal;
	
	Payment pay= new Payment();
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cart frame = new Cart();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public void seataddtomenu(ArrayList <Integer> list)
	{
		list.add(12);
		list.add(7);
		list.add(9);
		list.add(18);
		list.add(21);
		list.add(25);
		list.add(29);
		list.add(35);
		list.add(39);
		list.add(45);
		list.add(49);
		list.add(3);
		list.add(5);
		list.add(31);
		list.add(40);
		list.add(15);
		list.add(19);
		list.add(27);
	}
	public void pass(String depart,String depar_time, String D1, String  Desti, String desti_time)
	{

		D=depart;
		D2=Desti;
		
		Duration=D1;
		JLabel Depart = new JLabel(depart);
		Depart.setBackground(Color.LIGHT_GRAY);
		Depart.setForeground(Color.BLACK);
		Depart.setFont(new Font("Tahoma", Font.BOLD, 12));
		Depart.setBounds(116, 59, 113, 23);
		Option.add(Depart);
		
		JLabel Destina = new JLabel(Desti);
		
		Destina.setBounds(123, 129, 106, 23);
		Option.add(Destina);
		
		JLabel time_depart = new JLabel(depar_time);
		time_depart.setBounds(122, 100, 107, 18);
		Option.add(time_depart);
		
		JLabel time2_destina = new JLabel(desti_time);
		time2_destina.setBounds(125, 163, 108, 23);
		Option.add(time2_destina);
		
		JLabel Duration = new JLabel(D1);
		Duration.setBounds(135, 192, 101, 15);
		Option.add(Duration);
	}
	
	public Cart() 
	{
		
		Islamabad_northairport f= new Islamabad_northairport();
		//ArrayList <Bookings> booking= new ArrayList <Bookings>();
		Bookings booking1= new Bookings();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 784, 595);
		Option = new JPanel();
		Option.setBackground(new Color(230, 230, 250));
		Option.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(Option);
		Option.setLayout(null);
		

		
		JLabel lblNewLabel = new JLabel("Cart:");
		lblNewLabel.setForeground(Color.BLUE);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBackground(Color.BLUE);
		lblNewLabel.setBounds(395, 17, 97, 28);
		Option.add(lblNewLabel);
		
		JLabel Departure_label = new JLabel("Departure:");
		Departure_label.setFont(new Font("Tahoma", Font.BOLD, 12));
		Departure_label.setBounds(10, 61, 76, 23);
		Option.add(Departure_label);
		
		JLabel Desrination_label = new JLabel("Destination:");
		Desrination_label.setFont(new Font("Tahoma", Font.BOLD, 12));
		Desrination_label.setBounds(10, 129, 106, 23);
		Option.add(Desrination_label);
		
		JLabel lblNewLabel_1 = new JLabel("Departure Time:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1.setBounds(10, 95, 114, 23);
		Option.add(lblNewLabel_1);
		
		JLabel Destination_time_label = new JLabel("Destination Time:");
		Destination_time_label.setFont(new Font("Tahoma", Font.BOLD, 13));
		Destination_time_label.setBounds(10, 163, 133, 18);
		Option.add(Destination_time_label);
		

		JLabel Depart = new JLabel();
		Depart.setBackground(Color.LIGHT_GRAY);
		Depart.setForeground(Color.BLACK);
		Depart.setFont(new Font("Tahoma", Font.BOLD, 12));
		Depart.setBounds(116, 59, 113, 23);
		Option.add(Depart);
		

		JLabel Destina = new JLabel("");
		Destina.setBounds(123, 129, 106, 23);
		Option.add(Destina);
		
		JLabel time_depart = new JLabel("");
		time_depart.setBounds(122, 100, 107, 18);
		Option.add(time_depart);
		
		JLabel time2_destina = new JLabel("");
		time2_destina.setBounds(121, 163, 108, 23);
		Option.add(time2_destina);
		
		JLabel lblNewLabel_2 = new JLabel("Duration");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2.setBounds(10, 192, 114, 18);
		Option.add(lblNewLabel_2);
		
		JLabel Data = new JLabel("Passenger select their seats(depend on gender)");
		Data.setFont(new Font("Tahoma", Font.BOLD, 13));
		Data.setBounds(246, 128, 364, 24);
		Option.add(Data);
		
		Entering_Data = new JTextField();
		Entering_Data.setBounds(387, 224, 178, 21);
		Option.add(Entering_Data);
		Entering_Data.setColumns(10);
		
		JLabel data1 = new JLabel("Enter the number of Seat:");
		data1.setFont(new Font("Tahoma", Font.BOLD, 13));
		data1.setBounds(246, 190, 212, 23);
		Option.add(data1);
		
		JLabel Total_tabel = new JLabel("Total Seat:");
		Total_tabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		Total_tabel.setBounds(246, 61, 82, 23);
		Option.add(Total_tabel);
		
		JLabel Total_seat = new JLabel(booking1.getTotal_seat());
		Total_seat.setBounds(387, 64, 71, 18);
		Option.add(Total_seat);
		
		JLabel Booked_label = new JLabel("Booked Seat:");
		Booked_label.setFont(new Font("Tahoma", Font.BOLD, 13));
		Booked_label.setAlignmentY(Component.BOTTOM_ALIGNMENT);
		Booked_label.setBounds(473, 63, 106, 19);
		Option.add(Booked_label);
		
		String book=String.valueOf(booking1.getBooked_seat());
		JLabel Bookedseat = new JLabel(book);
		Bookedseat.setBounds(615, 64, 79, 18);
		Option.add(Bookedseat);
		
		JLabel Remian_label = new JLabel("Available Seats:");
		Remian_label.setFont(new Font("Tahoma", Font.BOLD, 13));
		Remian_label.setBounds(246, 97, 114, 18);
		Option.add(Remian_label);
		
		String free= String.valueOf(booking1.getAvailable_seat());
		JLabel Available = new JLabel(free);
		Available.setBounds(387, 98, 76, 18);
		Option.add(Available);
		Entering_Data.getText();
		ArrayList_Data obj= new ArrayList_Data();
		
		obj.booking.add(booking1);
		

		txtTotalSeat = new JTextField();
		txtTotalSeat.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtTotalSeat.setText("Total Seat:");
		txtTotalSeat.setBounds(311, 288, 127, 23);
		Option.add(txtTotalSeat);
		txtTotalSeat.setColumns(10);
		
		JLabel TOTAL_seat = new JLabel("");
		TOTAL_seat.setBounds(501, 293, 105, 18);
		Option.add(TOTAL_seat);
		
		txtTotalAmount = new JTextField();
		txtTotalAmount.setFont(new Font("Tahoma", Font.BOLD, 13));
		txtTotalAmount.setText("Total Amount:");
		txtTotalAmount.setBounds(311, 333, 127, 23);
		Option.add(txtTotalAmount);
		txtTotalAmount.setColumns(10);
		
		JLabel Total_amount = new JLabel("");
		Total_amount.setBounds(501, 338, 86, 18);
		Option.add(Total_amount);
		
		txtTax = new JTextField();
		txtTax.setFont(new Font("Tahoma", Font.BOLD, 14));
		txtTax.setText("Tax:");
		txtTax.setBounds(311, 378, 127, 23);
		Option.add(txtTax);
		txtTax.setColumns(10);
		
		JLabel TAX = new JLabel("");
		TAX.setBounds(501, 378, 99, 18);
		Option.add(TAX);
		
		txtGrandTotal = new JTextField();
		txtGrandTotal.setFont(new Font("Tahoma", Font.BOLD, 14));
		txtGrandTotal.setText("Grand Total:");
		txtGrandTotal.setBounds(354, 454, 106, 28);
		Option.add(txtGrandTotal);
		txtGrandTotal.setColumns(10);
		
		JLabel GrandTotal = new JLabel("");
		GrandTotal.setBounds(491, 454, 106, 28);
		Option.add(GrandTotal);
		
		JCheckBox Man_button = new JCheckBox("Man");
		Man_button.setBackground(new Color(230, 230, 250));
		Man_button.setBounds(283, 162, 97, 23);
		Option.add(Man_button);
		
		JCheckBox Woman_button = new JCheckBox("Woman");
		Woman_button.setBackground(new Color(230, 230, 250));
		Woman_button.setBounds(395, 162, 97, 23);
		Option.add(Woman_button);
		
		JCheckBox Children_button = new JCheckBox("Children");
		Children_button.setBackground(new Color(230, 230, 250));
		Children_button.setBounds(500, 162, 97, 23);
		Option.add(Children_button);
		
		JButton BOOKED = new JButton("Add to cart");
		BOOKED.setBackground(new Color(0, 191, 255));
		
		BOOKED.addMouseListener(new MouseAdapter() 
		{
			int booked=0;
			int free1=0;
			int man=0;
			int woman1=0;
			int  children1=0;
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				
				String convert;
				int i= Integer.parseInt(Entering_Data.getText());
				pay.setSeat_no(i);
				ArrayList <Integer> checker= new ArrayList<Integer>();
				seataddtomenu( checker);
				boolean c=true;

			if(i> 0 || i<=50)
			{
				checker.add(i);	
				JOptionPane.showMessageDialog(null, "Sucessfully Added");
			
					if(Man_button.isSelected() || Woman_button.isSelected()|| Children_button .isSelected())
					{
						String tem= String.valueOf(i);
					int b=booking1.getBooked_seat();
					b=b+i;
					booking1.setBooked_seat(b);
					String total1= String.valueOf(booking1.getBooked_seat());
					Bookedseat.setText(total1);
					
					
					int f= booking1.getAvailable_seat();
					f=f-i;
					booking1.setAvailable_seat(f);
					String totalfree= String.valueOf(booking1.getAvailable_seat());
					Available.setText(totalfree);
					
					total=total+i;
					
				
//					int t;
//					t= Integer.parseInt(temp1);
//					total= total+t;
				
					}
					pay.setSeat_no(total);
					convert= String.valueOf(pay.getSeat_no());
				
					TOTAL_seat.setText(convert);
					
					
						int DURATION= Integer.parseInt(Duration);
						int seat_convertor= Integer.parseInt(convert);
						
						int totalprice=DURATION*seat_convertor*pay.getLocal_price();
						pay.setTotal_cost(totalprice);
						String amount= String.valueOf(pay.getTotal_cost());
						Total_amount.setText(amount);
					
						double t= (pay.getTax_local()*totalprice);
						
						String tax=Double.toString(t);
						TAX.setText(tax);
					
						double GRAND= pay.getTotal_cost()+t;
						pay.setGrand_total(GRAND);
						String grand= String.valueOf(pay.getGrand_total());
						GrandTotal.setText(grand);
					
//					else if(Woman_button.isSelected())
//					{
//						int b=booking1.getBooked_seat();
//						++b;
//						booking1.setBooked_seat(b);
//						String total1= String.valueOf(booking1.getBooked_seat());
//						Bookedseat.setText(total1);
//						
//						int f= booking1.getAvailable_seat();
//						--f;
//						booking1.setAvailable_seat(f);
//						String totalfree= String.valueOf(booking1.getAvailable_seat());
//						Available.setText(totalfree);
//						
//						++woman1;
//						temp2= String.valueOf(woman1);
//						Women_data.setText(temp2);
//						
//						int t2;
//						t2= Integer.valueOf(temp2);
//						total=total+t2;							 
//					}
//					else if(Children_button .isSelected())
//					{
//						
//						int b=booking1.getBooked_seat();
//						++b;
//						booking1.setBooked_seat(b);
//						String total1= String.valueOf(booking1.getBooked_seat());
//						Bookedseat.setText(total1);
//						
//						
//						int f= booking1.getAvailable_seat();
//						--f;
//						booking1.setAvailable_seat(f);
//						String totalfree= String.valueOf(booking1.getAvailable_seat());
//						Available.setText(totalfree);
//						
//						++children1;
//						temp3= String.valueOf(children1);
//						Child_data.setText(temp3);	
//						
//						int t3;
//						t3= Integer.valueOf(temp3);
//						total=total+t3;				
//					 }
				
			}
			if(i<0)
			{
				JOptionPane.showMessageDialog(null, "Please enter value between 1-50");
			}
   }
});
				
		BOOKED.setBounds(569, 254, 170, 23);
		Option.add(BOOKED);
		
		JLabel lblNewLabel_3 = new JLabel("Booking Details:");
		lblNewLabel_3.setForeground(Color.BLUE);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_3.setBounds(10, 13, 182, 37);
		Option.add(lblNewLabel_3);
		
		textField = new JTextField();
		textField.setBackground(Color.BLUE);
		textField.setBounds(220, 0, 9, 556);
		Option.add(textField);
		textField.setColumns(10);
		
		JButton Confirmation = new JButton("Confirm ");
		Confirmation.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				
				Confirmation c1= new Confirmation();
				
				c1.total_attain(pay.getGrand_total(),pay.getSeat_no());
				c1.setter(D, D2);
				c1.setVisible(true);
				dispose();
				

//				
			}
		});
		Confirmation.setBackground(new Color(95, 158, 160));
		Confirmation.setForeground(new Color(0, 0, 0));
		Confirmation.setFont(new Font("Tahoma", Font.BOLD, 13));
		Confirmation.setBounds(580, 522, 159, 23);
		Option.add(Confirmation);
		
		JButton btnNewButton = new JButton("BACK");
		btnNewButton.setBackground(new Color(95, 158, 160));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				Islamabad_northairport f= new Islamabad_northairport();
				f.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton.setBounds(10, 523, 89, 23);
		Option.add(btnNewButton);
		
		
		
		
		//CHECKOUT obj= new CHECKOUT();
		
		
		
		
}
}

