package business_layer;

public class Payment 
{
	protected int local_price= 10000;
	protected int international_price=20000;
	protected double tax_local=0.05;
	protected double inter_tax=0.1;
	
	protected int total_cost;
	protected double discount;
	protected double grand_total;
	protected int seat_no;
	
	
	public Payment(int local_price, int international_price, int total_cost, double discount,double local_tax,
			double grand, int seatno, double tax1) 
	{	
		this.local_price = local_price;
		this.international_price = international_price;
		this.total_cost = total_cost;
		this.discount = discount;
		this.tax_local= local_tax;
		this.grand_total=grand;
		this.seat_no= seatno;
		this.inter_tax= tax1;
	}
	public Payment()
	{
		
	}
	public double getInter_tax() {
		return inter_tax;
	}
	public void setInter_tax(double inter_tax) {
		this.inter_tax = inter_tax;
	}
	public int getSeat_no() {
		return seat_no;
	}
	public void setSeat_no(int seat_no) {
		this.seat_no = seat_no;
	}
	public double getGrand_total() {
		return grand_total;
	}
	public void setGrand_total(double grand_total) {
		this.grand_total = grand_total;
	}
	public double getTax_local() {
		return tax_local;
	}
	public void setTax_local(double tax_local) {
		this.tax_local = tax_local;
	}
	public int getLocal_price() {
		return local_price;
	}
	public void setLocal_price(int local_price) {
		this.local_price = local_price;
	}
	public int getInternational_price() {
		return international_price;
	}
	public void setInternational_price(int international_price) {
		this.international_price = international_price;
	}
	public int getTotal_cost() {
		return total_cost;
	}
	public void setTotal_cost(int total_cost) {
		this.total_cost = total_cost;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	
	

}
