package business_layer;

public class International extends Flights
{
	
	public static String Country1= "Canada";
	public static  String country2= "America";
	public static  String country3= "Saudia Arabia";
	public static  String country4= "UK";
	public static String country5= "Dubai";
	
	
	public static  String Time1= "20";
	public static  String Time2= "3";
	public static  String Time3= "9";
	public static  String Time4= "12";
	public static  String Time5= "18";
	
	public static  String Time1_arrival= "25";
	public static  String Time2_arrival= "8";
	public static  String Time3_arrival= "14";
	public static  String Time4_arrival= "19";
	public static  String Time5_arrival= "23";
	
	public static String duration="5";
	
	public International(String departure, String departure_time, String hours_need, String destination,
			String destination_time, int available_seat, int booked_seat, String country1, String country2,
			String country3, String country4, String country5, String time1, String time2, String time3, String time4,
			String time5) {
		super(departure, departure_time, hours_need, destination, destination_time, available_seat, booked_seat);
		Country1 = country1;
		this.country2 = country2;
		this.country3 = country3;
		this.country4 = country4;
		this.country5 = country5;
		Time1 = time1;
		Time2 = time2;
		Time3 = time3;
		Time4 = time4;
		Time5 = time5;
	}
	public International()
	{
		
	}
	
	public static String getDuration() {
		return duration;
	}
	public static void setDuration(String duration) {
		International.duration = duration;
	}
	public static String getCountry1() {
		return Country1;
	}
	public static void setCountry1(String country1) {
		Country1 = country1;
	}
	public static String getCountry2() {
		return country2;
	}
	public static void setCountry2(String country2) {
		International.country2 = country2;
	}
	public static String getCountry3() {
		return country3;
	}
	public static void setCountry3(String country3) {
		International.country3 = country3;
	}
	public static String getCountry4() {
		return country4;
	}
	public static void setCountry4(String country4) {
		International.country4 = country4;
	}
	public static String getCountry5() {
		return country5;
	}
	public static void setCountry5(String country5) {
		International.country5 = country5;
	}
	public static String getTime1() {
		return Time1;
	}
	public static void setTime1(String time1) {
		Time1 = time1;
	}
	public static String getTime2() {
		return Time2;
	}
	public static void setTime2(String time2) {
		Time2 = time2;
	}
	public static String getTime3() {
		return Time3;
	}
	public static void setTime3(String time3) {
		Time3 = time3;
	}
	public static String getTime4() {
		return Time4;
	}
	public static void setTime4(String time4) {
		Time4 = time4;
	}
	public static String getTime5() {
		return Time5;
	}
	public static void setTime5(String time5) {
		Time5 = time5;
	}
	public static String getTime1_arrival() {
		return Time1_arrival;
	}
	public static void setTime1_arrival(String time1_arrival) {
		Time1_arrival = time1_arrival;
	}
	public static String getTime2_arrival() {
		return Time2_arrival;
	}
	public static void setTime2_arrival(String time2_arrival) {
		Time2_arrival = time2_arrival;
	}
	public static String getTime3_arrival() {
		return Time3_arrival;
	}
	public static void setTime3_arrival(String time3_arrival) {
		Time3_arrival = time3_arrival;
	}
	public static String getTime4_arrival() {
		return Time4_arrival;
	}
	public static void setTime4_arrival(String time4_arrival) {
		Time4_arrival = time4_arrival;
	}
	public static String getTime5_arrival() {
		return Time5_arrival;
	}
	public static void setTime5_arrival(String time5_arrival) {
		Time5_arrival = time5_arrival;
	}
	

	
	

	
	
	

}
