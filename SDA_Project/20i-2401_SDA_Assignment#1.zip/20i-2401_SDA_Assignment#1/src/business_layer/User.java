package business_layer;

public class User 
{
							//Used all the parameter constructor and non-parameter constructor
	protected String USERNAME;
	protected String Password;
	
	public User(String USERNAME, String Password) 
	{
		
		this.USERNAME = USERNAME;
		this.Password = Password;
	}
	public User(){	
	}
	public String getUSERNAME() {
		return USERNAME;
	}
	public void setUSERNAME(String USERNAME) {
		this.USERNAME = USERNAME;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}


}
