package business_layer;

public class Passenger extends User	//Extends the user because it have same attributes
{
	private String First_name;
	private String last_name;
	private boolean Passport;
	private boolean visa;
	private String CNIC;
	private boolean vaccination;
	
									//Parameter Constructor
	public Passenger(String uSERNAME, String password, String first_name, String last_name, boolean passport,
			boolean visa, String cNIC, boolean vaccination) 
	{
		super(uSERNAME, password);
		First_name = first_name;
		this.last_name = last_name;
		Passport = passport;
		this.visa = visa;
		CNIC = cNIC;
		this.vaccination = vaccination;
	}
						//Non-parameter constructor...Default Constructor
	public Passenger(){	
	}
	
									//All getter setter of all attributes
	public String getFirst_name() {
		return First_name;
	}
	public void setFirst_name(String first_name) {
		First_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public boolean isPassport() {
		return Passport;
	}
	public void setPassport(boolean passport) {
		Passport = passport;
	}
	public boolean isVisa() {
		return visa;
	}
	public void setVisa(boolean visa) {
		this.visa = visa;
	}
	public String getCNIC() {
		return CNIC;
	}
	public void setCNIC(String cNIC) {
		CNIC = cNIC;
	}
	public boolean isVaccination() {
		return vaccination;
	}
	public void setVaccination(boolean vaccination) {
		this.vaccination = vaccination;
	}
	@Override
	public String toString() {
		return "Passenger [First_name=" + First_name + ", last_name=" + last_name + ", Passport=" + Passport + ", visa="
				+ visa + ", CNIC=" + CNIC + ", vaccination=" + vaccination + ", USERNAME=" + USERNAME + ", Password="
				+ Password + "]";
	}
	
	

}
