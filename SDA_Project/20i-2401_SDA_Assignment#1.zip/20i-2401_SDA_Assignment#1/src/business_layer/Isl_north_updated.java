package business_layer;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Isl_north_updated extends JFrame {

	private JPanel contentPane;
	private JTable table;
	DefaultTableModel model;
	private JLabel lblNewLabel;
	private JButton Back_button;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Islamabad_northairport frame = new Islamabad_northairport();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	public Isl_north_updated()
	{
		//private final List<Book> books;
		//List<Book> book = new ArrayList<Book>();
		//final ArrayList <Flights> flight= new ArrayList <Flights>();
		//AdminUpadateClass admin= new AdminUpadateClass();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 200, 900, 450);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
			
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 48, 816, 173);
		contentPane.add(scrollPane);
		
		String column[]= {"Sr.No ","Departure", "Departure(Hours-24)", "Duration", "Destination", "Destination(Hours-24)"};
		final Local object1= new Local();
		Local object2= new Local();	
		Local object3= new Local();
		Local object4= new Local();
		Local object5= new Local();
		Local object6=new Local();
		Local object7= new Local();
		Local object8= new Local();
		Local object9= new Local();
		Local object10= new Local();
		String[][] data= {
				{"1",Local.getDestination_city(), Local.getTime1_depar(), Local.getDuration(), Local.getCity1_Desti(), Local.getTime1_arrival()},
				{"2",Local.getDestination_city(),	Local.getTime2_depar(),Local.getDuration(),Local.getCity3_Desti(),Local.getTime2_arrival()},
				{"3",Local.getDestination_city(), Local.getTime3_depar(),Local.getDuration(), Local.getCity4_Desti(), Local.getTime3_arrival() } ,
				{"4", Local.getDestination_city(),Local.getTime4_depar(),Local.getDuration(),Local.getCity5_Desti(), Local.getTime4_arrival()},
				{"5",Local.getDestination_city(),	Local.getTime5_depar(), Local.getDuration(), Local.getCity6_Desti(),Local.getTime5_arrival()},
				{"6", Local.getDestination_city(), Local.getTime6_depar(), Local.getDuration(), Local.getCity8_Desti(),Local.getTime6_arrival()},
				{"7", Local.getDestination_city(), Local.getTime7_depar(),Local.getDuration(), Local.getCity9_Desti(),Local.getTime7_arrival()},
				{"8", Local.getDestination_city(), Local.getTime8_depar(), Local.getDuration(), Local.getCity10_Desti(), Local.getTime8_arrival()},
				{"9", Local.getDestination_city(), Local.getTime9_depar(), Local.getDuration(), Local.getCity1_Desti(),Local.getTime9_arrival()},
				{"10", Local.getDestination_city(), Local.getTime10_depar(), Local.getDuration(), Local.getCity3_Desti(), Local.getTime10_arrival()}
		};
		table = new JTable(data, column);
		
	
		table.setFont(new Font("Tahoma", Font.BOLD, 12));
		table.setForeground(new Color(0, 0, 0));
		table.setBackground(new Color(211, 211, 211));
		
		

		

		
		scrollPane.setViewportView(table);
		
		lblNewLabel = new JLabel("Updation_Version");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setForeground(new Color(165, 42, 42));
		lblNewLabel.setBounds(294, 11, 168, 23);
		contentPane.add(lblNewLabel);
		
		Back_button = new JButton("BACK");
		Back_button.setBackground(new Color(95, 158, 160));
		Back_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				Admin_Islamabadnorth isl= new Admin_Islamabadnorth();
				isl.setVisible(true);
				dispose();
			}
		});
		Back_button.setBounds(53, 377, 89, 23);
		contentPane.add(Back_button);
		
		

		
	}

}
	

