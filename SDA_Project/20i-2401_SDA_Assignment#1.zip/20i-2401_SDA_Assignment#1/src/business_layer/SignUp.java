package business_layer;
import java.util.*;
import java.util.regex.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JPasswordField;
import javax.swing.JCheckBox;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class SignUp extends JFrame {

	private JPanel contentPane;
	

	/**
	 * Launch the application.
	 */
	//static ArrayList <Passenger> passenger_Details = new ArrayList<>();
	private JTextField text1;
	private JTextField text2;
	private JTextField USERNAME;
	private JTextField CNIC_field;
	private JPasswordField passowrd_field;
	private JPasswordField confirm_password;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SignUp frame = new SignUp();
					frame.setTitle("SIGN UP");
					frame.setVisible(true);
				} catch (Exception e) 
				{
					//System.out.println("ERROR OCCUR");
					e.printStackTrace();
				}
			}
		});
	}


	public boolean LowerCasePassword(String s) {
		boolean checker = false;
		
		for(int i = 0; i < s.length(); i++) {
			if(s.charAt(i) >= 'a' && s.charAt(i) <= 'z') {
				checker = true;
				break;
			}
		}
		
		
		return checker;
	}
	public static boolean isNumeric(String s) 
	{
	    if (s == null) {
	        return false;
	    }
	    try {
	        double d = Double.parseDouble(s);
	    } catch (NumberFormatException nfe) {
	        return false;
	    }
	    return true;
	}
	
	public boolean UpperCasePassword(String s) {
		boolean checker = false;
		for(int i= 0; i < s.length(); i++) {
			if(s.charAt(i) >= 'A' && s.charAt(i) <= 'Z') {
				checker = true;
				break;
			}
			
		}
		
		return checker;
	}
	
	public boolean ContainsSpecialCharacter(String s) {
		boolean checker = false;
		for(int i = 0 ; i<s.length(); i++) {
		if((s.charAt(i)>=32&&s.charAt(i)<=47)||(s.charAt(i)>=58&&s.charAt(i)<=64)||(s.charAt(i)>=91&&s.charAt(i)<=96)||(s.charAt(i)>=123&&s.charAt(i)<=126)) {
			
			
			checker=true;
			break;
			
		}
		}
		return checker;
	}
	
	public boolean cnic(String s) {
		boolean checker = false;
		int cnic = s.length();
		
		if(cnic == 13 && isNumeric(s) == true) {
			checker = true;
			
		}
		return checker;
	}
	
	/**
	 * Create the frame.
	 */

	public SignUp() {
		setBackground(new Color(240, 240, 240));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(400, 400, 600, 400);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel first = new JLabel("");
		first.setForeground(Color.RED);
		first.setBounds(164, 99, 126, 17);
		contentPane.add(first);
		
		JLabel last = new JLabel("");
		last.setFont(new Font("Tahoma", Font.BOLD, 11));
		last.setForeground(new Color(220, 20, 60));
		last.setBounds(409, 102, 126, 14);
		contentPane.add(last);
		
		JLabel user = new JLabel("");
		user.setFont(new Font("Tahoma", Font.BOLD, 11));
		user.setForeground(new Color(178, 34, 34));
		user.setBounds(162, 154, 128, 17);
		contentPane.add(user);
		

		JLabel Pass = new JLabel("");
		Pass.setForeground(new Color(139, 0, 0));
		Pass.setFont(new Font("Tahoma", Font.BOLD, 13));
		Pass.setBounds(10, 210, 97, 20);
		contentPane.add(Pass);
		
		JLabel name1 = new JLabel("First Name:");
		name1.setFont(new Font("Tahoma", Font.BOLD, 12));
		name1.setBounds(37, 70, 73, 17);
		contentPane.add(name1);
		
		JLabel name2 = new JLabel("Last Name:");
		name2.setFont(new Font("Tahoma", Font.BOLD, 12));
		name2.setBounds(300, 68, 73, 20);
		contentPane.add(name2);
	
		
		
		
		JLabel CNIC = new JLabel("CNIC");
		CNIC.setFont(new Font("Tahoma", Font.BOLD, 12));
		CNIC.setBounds(300, 122, 73, 20);
		contentPane.add(CNIC);
		

		text1 = new JTextField();
		text1.setBounds(142, 69, 86, 20);
		contentPane.add(text1);
		text1.setColumns(10);
		
		text2 = new JTextField();
		text2.setBounds(425, 71, 110, 20);
		contentPane.add(text2);
		text2.setColumns(10);
		
		USERNAME = new JTextField();
		USERNAME.setBounds(142, 127, 86, 20);
		contentPane.add(USERNAME);
		USERNAME.setColumns(10);
		
		passowrd_field = new JPasswordField();
		passowrd_field.setBounds(142, 182, 86, 20);
		contentPane.add(passowrd_field);
		
		confirm_password = new JPasswordField();
		confirm_password.setBounds(424, 181, 111, 20);
		contentPane.add(confirm_password);
		
		CNIC_field = new JTextField();
		CNIC_field.setBounds(425, 127, 110, 20);
		contentPane.add(CNIC_field);
		CNIC_field.setColumns(10);
		
		JLabel confirm = new JLabel("Confirm Password:");
		confirm.setFont(new Font("Tahoma", Font.BOLD, 11));
		confirm.setBounds(297, 182, 117, 19);
		contentPane.add(confirm); 
		
		JLabel password = new JLabel("Password");
		password.setFont(new Font("Tahoma", Font.BOLD, 12));
		password.setBounds(37, 184, 75, 17);
		contentPane.add(password);
		
		JCheckBox passport_filed = new JCheckBox("Passport");
		passport_filed.setBackground(new Color(135, 206, 235));
		passport_filed.setBounds(193, 258, 97, 23);
		contentPane.add(passport_filed);
		
		JCheckBox visa_field = new JCheckBox("Visa");
		visa_field.setBackground(new Color(135, 206, 235));
		visa_field.setBounds(76, 258, 97, 23);
		contentPane.add(visa_field);

		JCheckBox vaccination_field = new JCheckBox("Vaccination");
		vaccination_field.setBackground(new Color(135, 206, 235));
		vaccination_field.setBounds(317, 258, 97, 23);
		contentPane.add(vaccination_field);
		
		JLabel result = new JLabel("");
		result.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				Signin obj= new Signin();
				obj.setVisible(true);
				dispose();
			}
		}
		);
		result.setBounds(462, 272, 116, 30);
		contentPane.add(result);
		
		JButton Signup_button = new JButton("SIGN UP");
		Signup_button.setForeground(new Color(0, 0, 0));
		Signup_button.setFont(new Font("Tahoma", Font.BOLD, 11));
		Signup_button.setBackground(new Color(95, 158, 160));
		Signup_button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				
			}
		});
		Signup_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{				
				Signin si = new Signin();
				Passenger passenger= new Passenger();
				boolean check = false;
			if(text1.getText().isBlank() || text2.getText().isBlank() || USERNAME.getText().isBlank()|| passowrd_field.getText().isBlank() 
			|| CNIC_field.getText().isBlank() )
			{
						JOptionPane.showMessageDialog(null, "All fields need to be filled.");
						check = false;
			}
			else 
			{
				check = true;
			}
	
			if(LowerCasePassword(passowrd_field.getText()) == true && UpperCasePassword(passowrd_field.getText()) == true && 
					ContainsSpecialCharacter(passowrd_field.getText()) == true ) 
			{
				check = true;
			}
			else 
			{
				JOptionPane.showMessageDialog(null, "The message should contain lowercase, uppercase and special characters.");
				check = false;
			}
		if(cnic(CNIC_field.getText()) == true)
		{
			check = true;
		}			
		else 
		{
			JOptionPane.showMessageDialog(null, "Only numeric and 13 digits is required.");
			check = false;
		}	
			
		if(check == true) 
		{
			
			if(passowrd_field.getText().equals(confirm_password.getText())) 
			{
				
				passenger.setFirst_name(text1.getText());
				passenger.setLast_name(text2.getText());
				passenger.setUSERNAME(USERNAME.getText());
				passenger.setPassword(passowrd_field.getText());
				passenger.setCNIC(CNIC_field.getText());
				
				//passenger.setCNIC(cnic);
				
				if(visa_field.isSelected())
				{
					passenger.setVisa(true);
				}
				if(passport_filed.isSelected())
				{
					passenger.setPassport(true);
				}
				if(vaccination_field.isSelected())
				{
					passenger.setVaccination(true);
				}
				si.signUp(passenger); 	
			String name=	USERNAME.getText();
			String password= passowrd_field.getText();
				si.validation(name,password);
				JOptionPane.showMessageDialog(null, "Account Created");
				Signin in= new Signin();
				in.setVisible(true);
				dispose();
			}
			else
			 {
				JOptionPane.showMessageDialog(null, "Password fields do not match", "Error", JOptionPane.ERROR_MESSAGE);
			 }
		}
		else
		{
			JOptionPane.showMessageDialog(null, "Credentials are not valid." );
		}
		


			}
		});
		Signup_button.setBounds(242, 329, 89, 23);
		contentPane.add(Signup_button);
		
		JButton btnNewButton = new JButton("Back ");
		btnNewButton.setBackground(new Color(95, 158, 160));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				Signin obj= new Signin();
				obj.setVisible(true);
				dispose();
				
			}
		});
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		JButton Login1 = new JButton("Login In");
		Login1.setFont(new Font("Tahoma", Font.BOLD, 11));
		Login1.setBackground(new Color(95, 158, 160));
		Login1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				//if()
				Signin si= new Signin();
				
				si.setVisible(true);
				dispose();
				
			
				
			}
		});
		Login1.setBounds(485, 329, 89, 23);
		contentPane.add(Login1);
		
		JLabel username = new JLabel("User Name:");
		username.setFont(new Font("Tahoma", Font.BOLD, 13));
		username.setBounds(37, 122, 95, 20);
		contentPane.add(username);
		
		JLabel lblNewLabel = new JLabel("SignUp Page");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setBackground(new Color(240, 240, 240));
		lblNewLabel.setBounds(207, 23, 126, 23);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton_1 = new JButton("BACK");
		btnNewButton_1.setBackground(new Color(95, 158, 160));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				Signin in= new Signin();
				in.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_1.setBounds(10, 329, 89, 23);
		contentPane.add(btnNewButton_1);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
		
		
	}
}
