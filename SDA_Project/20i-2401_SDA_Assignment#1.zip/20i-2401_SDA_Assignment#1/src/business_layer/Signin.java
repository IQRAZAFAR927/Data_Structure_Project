package business_layer;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import data_layer.ArrayList_Data;
import presentation_layer.Details;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.awt.Color;
import javax.swing.JPasswordField;

public class Signin extends JFrame {

	private JPanel contentPane;
	private JTextField user_name;
	
	/**
	 * Launch the application.
	 */
	//static ArrayList <Passenger> passenger_Details = new ArrayList<>();
	private JPasswordField userpassword;
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Signin frame = new Signin();
					frame.setVisible(true);
					frame.setTitle("SIGN IN");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	ArrayList_Data obj= new ArrayList_Data();
	
	public void signUp(Passenger passenger)
	{
		obj.passenger_Details.add(passenger);
	}
	
//	public boolean checkusername(String username)
//	{
//		boolean checker1= false;
//		for(int i=0; i<obj.passenger_Details.size();i++)
//		{
//			if(obj.passenger_Details.get(i).getUSERNAME().equals(username))
//			{
//				checker1= true;
//			}
//		}
//		return checker1;
//	}
//	public boolean checkpassword(String password)
//	{
//		boolean checker2=false;
//		for(int i=0; i<obj.passenger_Details.size();i++)
//		{
//			if(obj.passenger_Details.get(i).getPassword().equals(password))
//			{
//				checker2=true;
//			}
//		}
//		return checker2;
//	}
//	
	
//	public boolean login(String username, String password)
//	{
//		boolean check=false;
//		for(int i=0; i<obj.passenger_Details.size();i++)
//		{
//			
//			if(obj.passenger_Details.get(i).getUSERNAME().equals(username) && obj.passenger_Details.get(i).getPassword().equals(password))
//			{
//				check= true;
//				return check;
//				
//			}
//		}
//		
//		return check;
//	}
	
	public boolean validation(String username, String password)
	{
		 if(username.equals( user_name.getText()) && password.equals( userpassword.getText()) )
		 {
			 return true;
		 }
		return false;
	}
	
	public Signin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Login in");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(145, 11, 106, 27);
		contentPane.add(lblNewLabel);
		
		JLabel userfield = new JLabel("Enter UserName:");
		userfield.setFont(new Font("Tahoma", Font.BOLD, 11));
		userfield.setBounds(10, 31, 159, 27);
		contentPane.add(userfield);
		
		user_name = new JTextField();
		user_name.setBounds(109, 57, 159, 20);
		contentPane.add(user_name);
		user_name.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Enter Password:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_1.setBounds(10, 88, 106, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Don't you have any account.");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_2.setBounds(38, 142, 186, 20);
		contentPane.add(lblNewLabel_2);
		
		JLabel Show = new JLabel("");
		Show.setBounds(318, 205, 89, 14);
		contentPane.add(Show);
		
		userpassword = new JPasswordField();
		userpassword.setBounds(109, 111, 159, 20);
		contentPane.add(userpassword);
		
		JButton btnNewButton = new JButton("Back ");
		btnNewButton.setBackground(new Color(95, 158, 160));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				SignUp up= new SignUp();
				up.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(10, 230, 89, 20);
		contentPane.add(btnNewButton);
		
		JButton Signup_button = new JButton("Sign Up");
		Signup_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				SignUp obj= new SignUp();
				obj.setVisible(true);
				dispose();
			}
		});
		Signup_button.setForeground(Color.BLACK);
		Signup_button.setBackground(new Color(95, 158, 160));
		Signup_button.setBounds(213, 142, 89, 23);
		contentPane.add(Signup_button);
		
		JButton btnNewButton_1 = new JButton("LOGIN IN");
		btnNewButton_1.setBackground(new Color(0, 191, 255));
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				String user= user_name.getText();
				String password= userpassword.getText();
				
				
//				 if(login(user,password) == true)
//				{
					
					//Show.setText("Account created");
				if(validation(user,password)==true)
				{
					JOptionPane.showMessageDialog(null, "Account Created");
					
					Details detail= new Details();
					detail.setVisible(true);
					dispose();
				}
//					TypeofAirport type= new TypeofAirport();
//					type.setVisible(true);
//					dispose();
					
				//}
//				 else if(login(user,password)==false)
//				 {
//					 if(  checkusername(user)== false && checkpassword(password) ==false  )
//					 {
//						 JOptionPane.showMessageDialog(null, "Invalid username and password");
//					 }
//					 if(checkusername(user)==false)
//						{
//							JOptionPane.showMessageDialog(null, "Invalid username");
//							
//						}
//					 if(checkpassword(password)==false)
//						{
//							JOptionPane.showMessageDialog(null, "Invalid password");
//							
//						}
//					 
//				 }
//				 else if(login(user,password)==false)
//				 {
//					 JOptionPane.showMessageDialog(null, " InValid username and Password");
//				 }
//				 else
//				 {
//					//Show.setText("No Account");
//					JOptionPane.showMessageDialog(null, " InValid username and Password");
//				 }
				
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton_1.setBounds(135, 188, 89, 23);
		contentPane.add(btnNewButton_1);
		
		
		
	
		
		
	}
}
