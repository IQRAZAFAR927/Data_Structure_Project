package business_layer;

public class Local extends Flights
{

	public static  String Destination_city="Islamabad";
	
	public static String Destination_city1= "Lahore";
	public static String  Destination_city2= "Peshawar";
	public static  String Destination_city3= "Karachi";
	public static String Destination_city4="Quetta";
	public static String duration="2";
	
	
	
	
	public  static String city1_Desti="Peshwar";
	protected static String city2_Desti="Islamabad";
	protected static  String city3_Desti="Lahore";
	protected static String city4_Desti= "Karachi";
	protected static String city5_Desti= "Quetta";
	public  static String city6_Desti="Peshwar";
	protected static String city7_Desti="Islamabad";
	protected static  String city9_Desti="Lahore";
	protected static String city8_Desti= "Karachi";
	protected static String city10_Desti= "Quetta";
	
	public static  String time1_depar="1";
	public static String  time2_depar= "3";
	public static String time3_depar="5";
	public static String time4_depar="7";
	public static String time5_depar="11";
	public static String time6_depar="13";
	public static String time7_depar="15";
	public static String time8_depar="17";
	public static String time9_depar="19";
	public static String time10_depar="21";
	
	
	public static  String time1_arrival="3";
	public static  String time2_arrival="5";
	public static  String time3_arrival="7";
	public static String time4_arrival="9";
	public  static String time5_arrival="13";
	public static  String time6_arrival="15";
	public static  String time7_arrival="17";
	public static  String time8_arrival="19";
	public static String time9_arrival="21";
	public  static String time10_arrival="23";
	
	public Local()
	{}
//	public Local(String departure, String departure_time, String hours_need, String destination,
//			String destination_time, int available_seat, int booked_seat, String city6_Desti, String city7_Desti,
//			String city9_Desti, String city8_Desti, String city10_Desti, String time1_depar, String time2_depar,
//			String time3_depar, String time4_depar, String time5_depar, String time6_arrival, String time7_arrival,
//			String time8_arrival, String time9_arrival, String time10_arrival, String destination_city, String city2, 
//		  String city3, String city4, String city5) 
//	{
//		super(departure, departure_time, hours_need, destination, destination_time, available_seat, booked_seat);
//	
//		this.city6_Desti = city6_Desti;
//		this.city7_Desti = city7_Desti;
//		this.city9_Desti = city9_Desti;
//		this.city8_Desti = city8_Desti;
//		this.city10_Desti = city10_Desti;
//		this.time1_depar = time1_depar;
//		this.time2_depar = time2_depar;
//		this.time3_depar = time3_depar;
//		this.time4_depar = time4_depar;
//		this.time5_depar = time5_depar;
//		this.time6_arrival = time6_arrival;
//		this.time7_arrival = time7_arrival;
//		this.time8_arrival = time8_arrival;
//		this.time9_arrival = time9_arrival;
//		this.time10_arrival = time10_arrival;
//		this.Destination_city=destination_city;
//		this.Destination_city1= city2;
//		this.Destination_city2= city3;
//		this.Destination_city3= city4;
//		this.Destination_city4= city5;
//	}
	
	
	public static String getDuration() {
		return duration;
	}
	public static String getTime6_depar() {
		return time6_depar;
	}


	public static void setTime6_depar(String time6_depar) {
		Local.time6_depar = time6_depar;
	}


	public static String getTime7_depar() {
		return time7_depar;
	}


	public static void setTime7_depar(String time7_depar) {
		Local.time7_depar = time7_depar;
	}


	public static String getTime8_depar() {
		return time8_depar;
	}


	public static void setTime8_depar(String time8_depar) {
		Local.time8_depar = time8_depar;
	}


	public static String getTime9_depar() {
		return time9_depar;
	}


	public static void setTime9_depar(String time9_depar) {
		Local.time9_depar = time9_depar;
	}


	public static String getTime10_depar() {
		return time10_depar;
	}


	public static void setTime10_depar(String time10_depar) {
		Local.time10_depar = time10_depar;
	}


	public static String getTime1_arrival() {
		return time1_arrival;
	}


	public static void setTime1_arrival(String time1_arrival) {
		Local.time1_arrival = time1_arrival;
	}


	public static String getTime2_arrival() {
		return time2_arrival;
	}


	public static void setTime2_arrival(String time2_arrival) {
		Local.time2_arrival = time2_arrival;
	}


	public static String getTime3_arrival() {
		return time3_arrival;
	}


	public static void setTime3_arrival(String time3_arrival) {
		Local.time3_arrival = time3_arrival;
	}


	public static String getTime4_arrival() {
		return time4_arrival;
	}


	public static void setTime4_arrival(String time4_arrival) {
		Local.time4_arrival = time4_arrival;
	}


	public static String getTime5_arrival() {
		return time5_arrival;
	}


	public static void setTime5_arrival(String time5_arrival) {
		Local.time5_arrival = time5_arrival;
	}


	public static void setDuration(String duration) {
		Local.duration = duration;
	}
	public static String getDestination_city1() {
		return Destination_city1;
	}
	public static void setDestination_city1(String destination_city1) {
		Destination_city1 = destination_city1;
	}
	public static String getDestination_city() {
		return Destination_city;
	}
	public static void setDestination_city(String destination_city) {
		Destination_city = destination_city;
	}
	
	
	public static String getDestination_city2() {
		return Destination_city2;
	}
	public static String getCity1_Desti() {
		return city1_Desti;
	}
	public static void setCity1_Desti(String city1_Desti) {
		Local.city1_Desti = city1_Desti;
	}
	public static String getCity2_Desti() {
		return city2_Desti;
	}
	public static void setCity2_Desti(String city2_Desti) {
		Local.city2_Desti = city2_Desti;
	}
	public static String getCity3_Desti() {
		return city3_Desti;
	}
	public static void setCity3_Desti(String city3_Desti) {
		Local.city3_Desti = city3_Desti;
	}
	public static String getCity4_Desti() {
		return city4_Desti;
	}
	public static void setCity4_Desti(String city4_Desti) {
		Local.city4_Desti = city4_Desti;
	}
	public static String getCity5_Desti() {
		return city5_Desti;
	}
	public static void setCity5_Desti(String city5_Desti) {
		Local.city5_Desti = city5_Desti;
	}
	public static  void setDestination_city2(String destination_city2) {
		Local.Destination_city2 = destination_city2;
	}
	public static String getDestination_city3() {
		return Destination_city3;
	}
	public static void setDestination_city3(String destination_city3) {
		Local.Destination_city3 = destination_city3;
	}
	public static String getDestination_city4() {
		return Destination_city4;
	}
	public static  void setDestination_city4(String destination_city4) {
		Local.Destination_city4 = destination_city4;
	}
	public static String getCity6_Desti() {
		return city6_Desti;
	}
	public static void setCity6_Desti(String city6_Desti) {
		Local.city6_Desti = city6_Desti;
	}
	public static  String getCity7_Desti() {
		return city7_Desti;
	}
	public  static void setCity7_Desti(String city7_Desti) {
		Local.city7_Desti = city7_Desti;
	}
	public  static String getCity9_Desti() {
		return city9_Desti;
	}
	public  static void setCity9_Desti(String city9_Desti) {
		Local.city9_Desti = city9_Desti;
	}
	public  static String getCity8_Desti() {
		return city8_Desti;
	}
	public  static void setCity8_Desti(String city8_Desti) {
		Local.city8_Desti = city8_Desti;
	}
	public  static String getCity10_Desti() {
		return city10_Desti;
	}
	public  static void setCity10_Desti(String city10_Desti) {
		Local.city10_Desti = city10_Desti;
	}
	public  static String getTime1_depar() {
		return time1_depar;
	}
	public  static void setTime1_depar(String time1_depar) {
		Local.time1_depar = time1_depar;
	}
	public  static String getTime2_depar() {
		return time2_depar;
	}
	public  static void setTime2_depar(String time2_depar) {
		Local.time2_depar = time2_depar;
	}
	public  static String getTime3_depar() {
		return time3_depar;
	}
	public  static void setTime3_depar(String time3_depar) {
		Local.time3_depar = time3_depar;
	}
	public  static String getTime4_depar() {
		return time4_depar;
	}
	public  static void setTime4_depar(String time4_depar) {
		Local.time4_depar = time4_depar;
	}
	public  static String getTime5_depar() {
		return time5_depar;
	}
	public  static void setTime5_depar(String time5_depar) {
		Local.time5_depar = time5_depar;
	}
	public  static String getTime6_arrival() {
		return time6_arrival;
	}
	public  static void setTime6_arrival(String time6_arrival) {
		Local.time6_arrival = time6_arrival;
	}
	public  static String getTime7_arrival() {
		return time7_arrival;
	}
	public  static void setTime7_arrival(String time7_arrival) {
		Local.time7_arrival = time7_arrival;
	}
	public  static String getTime8_arrival() {
		return time8_arrival;
	}
	public  static void setTime8_arrival(String time8_arrival) {
		Local.time8_arrival = time8_arrival;
	}
	public  static String getTime9_arrival() {
		return time9_arrival;
	}
	public static void setTime9_arrival(String time9_arrival) {
		Local.time9_arrival = time9_arrival;
	}
	public  static String getTime10_arrival() {
		return time10_arrival;
	}
	public  static void setTime10_arrival(String time10_arrival) {
	Local.time10_arrival = time10_arrival;
	}
	
		
	
	
	
	
	
	
	
}
