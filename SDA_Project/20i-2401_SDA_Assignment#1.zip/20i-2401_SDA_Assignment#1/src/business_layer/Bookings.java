package business_layer;

public class Bookings 
{
	protected String total_seat="50";
	protected int available_seat=32;
	protected int booked_seat=18;
	protected int total_person;
	protected int man;
	protected int woman;
	protected int children;
	protected int seat_no;
	
	
	
	public Bookings(String total_seat, int available_seat, int booked_seat, int total_person, int man, int woman,
			int children, int seat_no) 
	{
		this.total_seat = total_seat;
		this.available_seat = available_seat;
		this.booked_seat = booked_seat;
		this.total_person = total_person;
		this.man = man;
		this.woman = woman;
		this.children = children;
		this.seat_no = seat_no;
	}
	public Bookings()
	{
		
	}
	public String getTotal_seat() {
		return total_seat;
	}
	public void setTotal_seat(String total_seat) {
		this.total_seat = total_seat;
	}
	public int getAvailable_seat() {
		return available_seat;
	}
	public void setAvailable_seat(int available_seat) {
		this.available_seat = available_seat;
	}
	public int getBooked_seat() {
		return booked_seat;
	}
	public void setBooked_seat(int booked_seat) {
		this.booked_seat = booked_seat;
	}
	public int getTotal_person() {
		return total_person;
	}
	public void setTotal_person(int total_person) {
		this.total_person = total_person;
	}
	public int getMan() {
		return man;
	}
	public void setMan(int man) {
		this.man = man;
	}
	public int getWoman() {
		return woman;
	}
	public void setWoman(int woman) {
		this.woman = woman;
	}
	public int getChildren() {
		return children;
	}
	public void setChildren(int children) {
		this.children = children;
	}
	public int getSeat_no() {
		return seat_no;
	}
	public void setSeat_no(int seat_no) {
		this.seat_no = seat_no;
	}
	
	
	

}
