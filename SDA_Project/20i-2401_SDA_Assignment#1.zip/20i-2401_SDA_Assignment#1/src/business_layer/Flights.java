package business_layer;

public class Flights
{
	protected String departure;
	protected String departure_time;
	protected String Hours_need;
	protected String Destination;
	protected String Destination_time;
	protected int available_seat;
	protected int booked_seat;
	public Flights(String departure, String departure_time, String hours_need, String destination,
			String destination_time, int available_seat, int booked_seat) {
		
		this.departure = departure;
		this.departure_time = departure_time;
		Hours_need = hours_need;
		Destination = destination;
		Destination_time = destination_time;
		this.available_seat = available_seat;
		this.booked_seat = booked_seat;
	}
	
	public Flights()
	{
		
	}

	public String getDeparture() {
		return departure;
	}

	public void setDeparture(String departure) {
		this.departure = departure;
	}

	public String getDeparture_time() {
		return departure_time;
	}

	public void setDeparture_time(String departure_time) {
		this.departure_time = departure_time;
	}

	public String getHours_need() {
		return Hours_need;
	}

	public void setHours_need(String hours_need) {
		Hours_need = hours_need;
	}

	public String getDestination() {
		return Destination;
	}

	public void setDestination(String destination) {
		Destination = destination;
	}

	public String getDestination_time() {
		return Destination_time;
	}

	public void setDestination_time(String destination_time) {
		Destination_time = destination_time;
	}

	public int getAvailable_seat() {
		return available_seat;
	}

	public void setAvailable_seat(int available_seat) {
		this.available_seat = available_seat;
	}

	public int getBooked_seat() {
		return booked_seat;
	}

	public void setBooked_seat(int booked_seat) {
		this.booked_seat = booked_seat;
	}
	
	
	
	

}
