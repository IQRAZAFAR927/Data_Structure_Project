package business_layer;

public class Admin extends User
{
//	private String name;
	
	

	
	public Admin(String uSERNAME, String password, String name)
	{
		super(uSERNAME, password);
	//	this.name = name;
	}
	

}
