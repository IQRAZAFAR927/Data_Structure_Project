package business_layer;
import java.util.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import presentation_layer.Adminoption;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Admin_Islamabadnorth extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Admin_Islamabadnorth frame = new Admin_Islamabadnorth();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	


	
	/**
	 * Create the frame.
	 */
	
	ArrayList <Local> local= new ArrayList<Local>();
	
	private final JPanel panel = new JPanel();
	private JTextField depar;
	private JTextField t1;
	private JTextField Duration;
	private JTextField t2;
	private JTextField desti;
	DefaultTableModel model;
	private JTable table_1;		
	public Admin_Islamabadnorth() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 923, 491);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		panel.setBackground(new Color(230, 230, 250));
		panel.setBounds(0, 0, 897, 452);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Departure:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setBounds(10, 33, 79, 30);
		panel.add(lblNewLabel);
		
		JLabel lblDestinationTime = new JLabel("Departure Time:");
		lblDestinationTime.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblDestinationTime.setBounds(10, 91, 123, 30);
		panel.add(lblDestinationTime);
		
		JLabel lblNewLabel_2 = new JLabel("Duration");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_2.setBounds(10, 137, 67, 30);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Destination Time:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3.setBounds(10, 198, 123, 30);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_1 = new JLabel("Destination");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(10, 252, 100, 20);
		panel.add(lblNewLabel_1);
		
		depar = new JTextField();
		depar.setBounds(81, 60, 86, 20);
		panel.add(depar);
		depar.setColumns(10);
		
		t1 = new JTextField();
		t1.setBounds(81, 121, 86, 20);
		panel.add(t1);
		t1.setColumns(10);
		
		Duration = new JTextField();
		Duration.setBounds(81, 178, 86, 20);
		panel.add(Duration);
		Duration.setColumns(10);
		
		t2 = new JTextField();
		t2.setBounds(81, 229, 86, 20);
		panel.add(t2);
		t2.setColumns(10);
		
		desti = new JTextField();
		desti.setBounds(81, 283, 86, 20);
		panel.add(desti);
		desti.setColumns(10);
		
		
		
		JLabel lblNewLabel_4 = new JLabel("Details");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_4.setBounds(60, 8, 107, 20);
		panel.add(lblNewLabel_4);
		
		
		
		
		JButton update_button = new JButton("UPDATE");
		update_button.setFont(new Font("Tahoma", Font.BOLD, 11));
		update_button.setBackground(new Color(176, 224, 230));
		update_button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
			{
				int element=table_1.getSelectedRow();
				if(element==0)
				{	
					model.setValueAt(depar.getText(), element, 0);
					Local.setDestination_city(depar.getText());
					
					model.setValueAt(t1.getText(), element, 1);
					Local.setTime1_depar(t1.getText());
				
					model.setValueAt(Duration.getText(), element, 2);
					Local.setDuration(Duration.getText());
					
					model.setValueAt(t2.getText(), element, 3);
					Local.setTime6_arrival(t2.getText());
				
					model.setValueAt(desti.getText(), element, 4);
					Local.setCity1_Desti(desti.getText());
					JOptionPane.showMessageDialog(null, "Updated Successfully");
				}
				else if(element==1)
				{	
					model.setValueAt(depar.getText(),1, 0);
					Local.setDestination_city(depar.getText());
					
					model.setValueAt(t1.getText(), 1, 1);
					Local.setTime2_depar(t1.getText());
				
					model.setValueAt(Duration.getText(), 1, 2);
					Local.setTime3_arrival(Duration.getText());
					
					model.setValueAt(t2.getText(), 1, 3);
					Local.setTime2_arrival(t2.getText());
				
					model.setValueAt(desti.getText(),1, 4);
					Local.setCity3_Desti(desti.getText());
					
					JOptionPane.showMessageDialog(null, "Updated Successfully");
				}
				else if(element==2)
				{	
					model.setValueAt(depar.getText(),2, 0);
					Local.setDestination_city(depar.getText());
					
					model.setValueAt(t1.getText(), 2, 1);
					Local.setTime3_depar(t1.getText());
				
					model.setValueAt(Duration.getText(), 2, 2);
					Local.setDuration(Duration.getText());
					
					model.setValueAt(t2.getText(), 2, 3);
					Local.setTime3_arrival(t2.getText());
				
					model.setValueAt(desti.getText(),2, 4);
					Local.setCity4_Desti(desti.getText());
					
					JOptionPane.showMessageDialog(null, "Updated Successfully");
				}
				else if(element==3)
				{	
					model.setValueAt(depar.getText(),element, 0);
					Local.setDestination_city(depar.getText());
					
					model.setValueAt(t1.getText(), element, 1);
					Local.setTime4_depar(t1.getText());
				
					model.setValueAt(Duration.getText(), element, 2);
					Local.setDuration(Duration.getText());
					
					model.setValueAt(t2.getText(), element, 3);
					Local.setTime4_arrival(t2.getText());
				
					model.setValueAt(desti.getText(),element, 4);
					Local.setCity5_Desti(desti.getText());
					
					JOptionPane.showMessageDialog(null, "Updated Successfully");
				}
				else if(element==4)
				{	
					model.setValueAt(depar.getText(),element, 0);
					Local.setDestination_city(depar.getText());
					
					model.setValueAt(t1.getText(), element, 1);
					Local.setTime5_depar(t1.getText());
				
					model.setValueAt(Duration.getText(), element, 2);
					Local.setDuration(Duration.getText());
					
					model.setValueAt(t2.getText(), element, 3);
					Local.setTime5_arrival(t2.getText());
				
					model.setValueAt(desti.getText(),element, 4);
					Local.setCity6_Desti(desti.getText());
					
					JOptionPane.showMessageDialog(null, "Updated Successfully");
				}
				else if(element==5)
				{	
					model.setValueAt(depar.getText(),element, 0);
					Local.setDestination_city(depar.getText());
					
					model.setValueAt(t1.getText(), element, 1);
					Local.setTime6_depar(t1.getText());
				
					model.setValueAt(Duration.getText(), element, 2);
					Local.setDuration(Duration.getText());
					
					model.setValueAt(t2.getText(), element, 3);
					Local.setTime6_arrival(t2.getText());
				
					model.setValueAt(desti.getText(),element, 4);
					Local.setCity8_Desti(desti.getText());
					
					JOptionPane.showMessageDialog(null, "Updated Successfully");
				}
				else if(element==6)
				{	
					model.setValueAt(depar.getText(),element, 0);
					Local.setDestination_city(depar.getText());
					
					model.setValueAt(t1.getText(), element, 1);
					Local.setTime7_depar(t1.getText());
				
					model.setValueAt(Duration.getText(), element, 2);
					Local.setDuration(Duration.getText());
					
					model.setValueAt(t2.getText(), element, 3);
					Local.setTime7_arrival(t2.getText());
				
					model.setValueAt(desti.getText(),element, 4);
					Local.setCity9_Desti(desti.getText());
					
					JOptionPane.showMessageDialog(null, "Updated Successfully");
				}
				else if(element==7)
				{	
					model.setValueAt(depar.getText(),element, 0);
					Local.setDestination_city(depar.getText());
					
					model.setValueAt(t1.getText(), element, 1);
					Local.setTime8_depar(t1.getText());
				
					model.setValueAt(Duration.getText(), element, 2);
					Local.setDuration(Duration.getText());
					
					model.setValueAt(t2.getText(), element, 3);
					Local.setTime8_arrival(t2.getText());
				
					model.setValueAt(desti.getText(),element, 4);
					Local.setCity10_Desti(desti.getText());
					
					JOptionPane.showMessageDialog(null, "Updated Successfully");
				}
				else if(element==8)
				{	
					model.setValueAt(depar.getText(),element, 0);
					Local.setDestination_city(depar.getText());
					
					model.setValueAt(t1.getText(), element, 1);
					Local.setTime9_depar(t1.getText());
				
					model.setValueAt(Duration.getText(), element, 2);
					Local.setDuration(Duration.getText());
					
					model.setValueAt(t2.getText(), element, 3);
					Local.setTime9_arrival(t2.getText());
				
					model.setValueAt(desti.getText(),element, 4);
					Local.setCity1_Desti(desti.getText());
					
					JOptionPane.showMessageDialog(null, "Updated Successfully");
				}
				else if(element==9)
				{	
					model.setValueAt(depar.getText(),element, 0);
					Local.setDestination_city(depar.getText());
					
					model.setValueAt(t1.getText(), element, 1);
					Local.setTime10_depar(t1.getText());
				
					model.setValueAt(Duration.getText(), element, 2);
					Local.setDuration(Duration.getText());
					
					model.setValueAt(t2.getText(), element, 3);
					Local.setTime10_arrival(t2.getText());
				
					model.setValueAt(desti.getText(),element, 4);
					Local.setCity2_Desti(desti.getText());
					
					JOptionPane.showMessageDialog(null, "Updated Successfully");
				}
				
			}
		});
		update_button.setBounds(619, 349, 89, 23);
		panel.add(update_button);
		
		JButton btnNewButton = new JButton("DELETE");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton.setBackground(new Color(95, 158, 160));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				int  i= table_1.getSelectedRow();
				if(i>=0)
				{
					model.removeRow(i);
					JOptionPane.showMessageDialog(null, "Delete Successfully");
					
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Please selected the row first");
				}
			}
		});
		btnNewButton.setBounds(420, 400, 89, 23);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("CLEAR");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton_1.setBackground(new Color(176, 224, 230));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				depar.setText("");
				t1.setText("");
				Duration.setText("");
				t2.setText("");
				desti.setText("");
			}
		});
		btnNewButton_1.setBounds(619, 400, 89, 23);
		panel.add(btnNewButton_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(281, 12, 606, 299);
		panel.add(scrollPane);
		
		table_1 = new JTable();
		table_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
					int element=table_1.getSelectedRow();
					if(table_1.isRowSelected(0))
					{
					depar.setText(model.getValueAt(element, 0).toString());
					t1.setText(model.getValueAt(element, 1).toString());
					Duration.setText(model.getValueAt(element, 2).toString());
					t2.setText(model.getValueAt(element ,3).toString());
					desti.setText(model.getValueAt(element, 4).toString());
					
										
					}
					else if(table_1.isRowSelected(1))
					{
					depar.setText(model.getValueAt(element, 0).toString());
					t1.setText(model.getValueAt(element, 1).toString());
					Duration.setText(model.getValueAt(element, 2).toString());
					t2.setText(model.getValueAt(element ,3).toString());
					desti.setText(model.getValueAt(element, 4).toString());					
					}
					else if(table_1.isRowSelected(2))
					{
					depar.setText(model.getValueAt(element, 0).toString());
					t1.setText(model.getValueAt(element, 1).toString());
					Duration.setText(model.getValueAt(element, 2).toString());
					t2.setText(model.getValueAt(element ,3).toString());
					desti.setText(model.getValueAt(element, 4).toString());					
					}
					else if(table_1.isRowSelected(3))
					{
					depar.setText(model.getValueAt(element, 0).toString());
					t1.setText(model.getValueAt(element, 1).toString());
					Duration.setText(model.getValueAt(element, 2).toString());
					t2.setText(model.getValueAt(element ,3).toString());
					desti.setText(model.getValueAt(element, 4).toString());					
					}
					else if(table_1.isRowSelected(4))
					{
					depar.setText(model.getValueAt(element, 0).toString());
					t1.setText(model.getValueAt(element, 1).toString());
					Duration.setText(model.getValueAt(element, 2).toString());
					t2.setText(model.getValueAt(element ,3).toString());
					desti.setText(model.getValueAt(element, 4).toString());					
					}
					else if(table_1.isRowSelected(5))
					{
					depar.setText(model.getValueAt(element, 0).toString());
					t1.setText(model.getValueAt(element, 1).toString());
					Duration.setText(model.getValueAt(element, 2).toString());
					t2.setText(model.getValueAt(element ,3).toString());
					desti.setText(model.getValueAt(element, 4).toString());					
					}
					else if(table_1.isRowSelected(6))
					{
					depar.setText(model.getValueAt(element, 0).toString());
					t1.setText(model.getValueAt(element, 1).toString());
					Duration.setText(model.getValueAt(element, 2).toString());
					t2.setText(model.getValueAt(element ,3).toString());
					desti.setText(model.getValueAt(element, 4).toString());					
					}
					else if(table_1.isRowSelected(7))
					{
					depar.setText(model.getValueAt(element, 0).toString());
					t1.setText(model.getValueAt(element, 1).toString());
					Duration.setText(model.getValueAt(element, 2).toString());
					t2.setText(model.getValueAt(element ,3).toString());
					desti.setText(model.getValueAt(element, 4).toString());					
					}
					else if(table_1.isRowSelected(9))
					{
					depar.setText(model.getValueAt(element, 0).toString());
					t1.setText(model.getValueAt(element, 1).toString());
					Duration.setText(model.getValueAt(element, 2).toString());
					t2.setText(model.getValueAt(element ,3).toString());
					desti.setText(model.getValueAt(element, 4).toString());					
					}
			}
		});
		table_1.setForeground(new Color(0, 0, 0));
		table_1.setBackground(new Color(253, 245, 230));
		scrollPane.setViewportView(table_1);
		model= new DefaultTableModel();
		JTextPane table = new JTextPane();
		table.setBackground(new Color(250, 240, 230));
		
		Object [] Column= {"Departure", "Departure time", "Duration", "Destination time", "Destination"};
		final Object[] row= new Object[5];
		model.setColumnIdentifiers(Column);
		
		/////   1
		table_1.setModel(model);
		row[0]= Local.getDestination_city();
		row[1]= Local.getTime1_depar();
		row[2]= Local.getDuration();
		row[3]= Local.getTime1_arrival();
		row[4]= Local.getCity1_Desti();
		model.addRow(row);
		
		////        2
		row[0]=Local.getDestination_city();
		row[1]= Local.getTime2_depar();
		row[2]= Local.getDuration();
		row[3]= Local.getTime2_arrival();
		row[4]= Local.getCity3_Desti();
		model.addRow(row);
		
		////          3
		row[0]= Local.getDestination_city();
		row[1]= Local.getTime3_depar();
		row[2]= Local.getDuration();
		row[3]= Local.getTime3_arrival();
		row[4]= Local.getCity4_Desti();
		model.addRow(row);
		
		//////////	4	
		row[0]= Local.getDestination_city();
		row[1]= Local.getTime4_depar();
		row[2]= Local.getDuration();
		row[3]= Local.getTime4_arrival();
		row[4]= Local.getCity5_Desti();
		model.addRow(row);
		
		////////	5
		row[0]= Local.getDestination_city();
		row[1]= Local.getTime5_depar();
		row[2]= Local.getDuration();
		row[3]= Local.getTime5_arrival();
		row[4]= Local.getCity6_Desti();
		model.addRow(row);
		
		
		/////	6
		row[0]= Local.getDestination_city();
		row[1]= Local.getTime6_depar();
		row[2]= Local.getDuration();
		row[3]= Local.getTime6_arrival();
		row[4]= Local.getCity8_Desti();
		model.addRow(row);
		
		////	7
		row[0]= Local.getDestination_city();
		row[1]= Local.getTime7_depar();
		row[2]= Local.getDuration();
		row[3]= Local.getTime7_arrival();
		row[4]= Local.getCity9_Desti();
		model.addRow(row);
		
		
		
		/////////8
		
		row[0]= Local.getDestination_city();
		row[1]= Local.getTime8_depar();
		row[2]= Local.getDuration();
		row[3]= Local.getTime8_arrival();
		row[4]= Local.getCity10_Desti();
		model.addRow(row);
		
		//////9
		row[0]= Local.getDestination_city();
		row[1]= Local.getTime9_depar();
		row[2]= Local.getDuration();
		row[3]= Local.getTime9_arrival();
		row[4]= Local.getCity10_Desti();
		model.addRow(row);
		
		

		
		JButton add_button = new JButton("ADD");
		add_button.setFont(new Font("Tahoma", Font.BOLD, 11));
		add_button.setBackground(new Color(176, 224, 230));
		add_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				if(depar.getText().equals("") || t1.getText().equals("") || Duration.getText().equals("") || desti.getText().equals("") || 
				t2.getText().equals(""))
					{
						JOptionPane.showMessageDialog(null, "Please fill all information");
					}
				else
				{
					row[0]= depar.getText();
					
					 Local.setDestination_city4(depar.getText());
					 
					row[1]= t1.getText();
					Local.setTime1_depar(t1.getText());
					
					row[2]= Duration.getText();
					
					row[3]= t2.getText();
					Local.setTime6_arrival(t2.getText());
					
					row[4]= desti.getText();
					
					
					model.addRow(row);
					
					depar.setText("");
					t1.setText("");
					Duration.setText("");
					t2.setText("");
					desti.setText("");
					JOptionPane.showMessageDialog(null, "Saved Successfully");
					
					//{"1",Local.getDestination_city(), Local.getTime1_depar(), "2", Local.getCity1_Desti(), Local.getTime6_arrival()},
					
				}
				
			}
		});
		
		add_button.setBounds(420, 349, 89, 23);
		panel.add(add_button);
		
		JButton Back_button = new JButton("BACK");
		Back_button.setBackground(new Color(95, 158, 160));
		Back_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				Adminoption option= new Adminoption();
				option.setVisible(true);
				dispose();
			}
		});
		Back_button.setBounds(10, 418, 89, 23);
		panel.add(Back_button);
		
		JButton btnNewButton_2 = new JButton("See Update version");
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				Isl_north_updated upadte= new Isl_north_updated();
				upadte.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBounds(184, 418, 162, 23);
		panel.add(btnNewButton_2);
	}
}
