package business_layer;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import presentation_layer.PassengerOption;

import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Isl_inter_north_updation extends JFrame {

	private JPanel contentPane;
	private JTable table1;
	DefaultTableModel model;
	private JLabel lblNewLabel;
	private JButton Back_button;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Islamabad_northairport frame = new Islamabad_northairport();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	public  Isl_inter_north_updation()
	{
		//private final List<Book> books;
		//List<Book> book = new ArrayList<Book>();
		//final ArrayList <Flights> flight= new ArrayList <Flights>();
		//AdminUpadateClass admin= new AdminUpadateClass();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 200, 900, 450);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
			
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 48, 816, 126);
		contentPane.add(scrollPane);
		
		String column[]= {"Sr.No ","Departure", "Departure(Hours-24)", "Duration", "Destination", "Destination(Hours-24)"};		
		Local city= new Local();
		
		
		String[][] data1= {
				{"1",Local.getDestination_city(), International.getTime1(), "5", International.getCountry1(), International.getTime1_arrival()},
				{"2",Local.getDestination_city(),International.getTime2(),"6",International.getCountry2(),International.getTime2_arrival()},
				{"3",Local.getDestination_city(),International.getTime3(),"3",International.getCountry5(), International.getTime3_arrival() } ,
				{"4", Local.getDestination_city(),International.getTime4(),"7",International.getCountry4(), International.getTime4()},
				{"5",Local.getDestination_city(),	International.getTime5(), "3", International.getCountry3(),International.getTime5_arrival()}
				 
		};
		table1 = new JTable(data1, column);
		
	
		table1.setFont(new Font("Tahoma", Font.BOLD, 12));
		table1.setForeground(new Color(0, 0, 0));
		table1.setBackground(new Color(240, 248, 255));
		
		
		
		
	
		
		
		
		scrollPane.setViewportView(table1);
		
		lblNewLabel = new JLabel("Updation version");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setForeground(new Color(165, 42, 42));
		lblNewLabel.setBounds(236, 11, 280, 23);
		contentPane.add(lblNewLabel);
		
		Back_button = new JButton("BACK");
		Back_button.setBackground(new Color(95, 158, 160));
		Back_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				PassengerOption option= new PassengerOption();
				option.setVisible(true);
				dispose();
			}
		});
		Back_button.setBounds(53, 377, 89, 23);
		contentPane.add(Back_button);
		
		
		
		
		
	}

}
	

