package presentation_layer;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import business_layer.Cart;
import business_layer.Islamabad_northairport;

import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


import business_layer.Local;
public class Peshawar_southairport extends JFrame {

	private JPanel contentPane;
	private JTable table1;
	DefaultTableModel model;
	private JButton btnNewButton;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JButton btnNewButton_1;
	private JButton Back_button;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Islamabad_northairport frame = new Islamabad_northairport();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	public Peshawar_southairport  ()
	{
		//private final List<Book> books;
		//List<Book> book = new ArrayList<Book>();
		//final ArrayList <Flights> flight= new ArrayList <Flights>();
		//AdminUpadateClass admin= new AdminUpadateClass();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(200, 200, 900, 450);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
			
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 48, 816, 173);
		contentPane.add(scrollPane);
		
		String column[]= {"Sr.No ","Departure", "Departure(Hours-24)", "Duration", "Destination", "Destination(Hours-24)"};
//		final Local obj1= new Local();
//		Local obj2= new Local();	
//		Local obj3= new Local();
//		Local obj4= new Local();
//		Local obj5= new Local();
//		Local obj6=new Local();
//		Local obj7= new Local();
//		Local obj8= new Local();
//		Local obj9= new Local();
//		Local obj10= new Local();
		//System.out.println(obj1.getDestination_city1());
		String[][] data1= {
				{"1",Local.getDestination_city2(), Local.getTime1_depar(),Local.getDuration(), Local.getCity2_Desti(), Local.getTime6_arrival()},
				{"2",Local.getDestination_city2(),Local.getTime2_depar(),Local.getDuration(),Local.getCity3_Desti(),Local.getTime7_arrival()},
				{"3",Local.getDestination_city2(), Local.getTime3_depar(), Local.getDuration(), Local.getCity5_Desti(), Local.getTime8_arrival() } ,
				{"4", Local.getDestination_city2(),Local.getTime4_depar(),Local.getDuration(),Local.getCity6_Desti(), Local.getTime9_arrival()},
				{"5",Local.getDestination_city2(),	Local.getTime5_depar(), Local.getDuration(), Local.getCity7_Desti(),Local.getTime10_arrival()},
				{"6", Local.getDestination_city2(), Local.getTime6_depar(),Local.getDuration(), Local.getCity8_Desti(),Local.getTime6_arrival()},
				{"7", Local.getDestination_city2(), Local.getTime7_depar(), Local.getDuration(), Local.getCity10_Desti(),Local.getTime9_arrival()},
				{"8", Local.getDestination_city2(),Local.getTime8_depar(),Local.getDuration(), Local.getCity4_Desti(), Local.getTime10_arrival()},
				{"9", Local.getDestination_city2(),Local.getTime9_depar(), Local.getDuration(), Local.getCity2_Desti(),Local.getTime8_arrival()},
				{"10", Local.getDestination_city2(), Local.getTime10_depar(), Local.getDuration(), Local.getCity3_Desti(), Local.getTime7_arrival()}
		};
		table1 = new JTable(data1, column);
		
	
		table1.setFont(new Font("Tahoma", Font.BOLD, 12));
		table1.setForeground(new Color(0, 0, 0));
		table1.setBackground(new Color(240, 248, 255));
		
		
			
//		flight.add(obj1);
//		flight.add(obj2);
//		flight.add(obj3);
//		flight.add(obj4);
//		flight.add(obj5);
//		flight.add(obj6);
		
	//	model= new DefaultTableModel();
		
//		model.setColumnIdentifiers(column);                                                                                            
//		table.setModel(model);
//	
//		
//		Object [] row1 = new Object[5];
//		Local object1= new Local();
//		row1[0]= object1.getCity1_Depar();
//		row1[1]= object1.getTime1_depar();
//		int time1= Integer.parseInt(object1.getTime1_depar());
//		int time2= Integer.parseInt(object1.getTime6_arrival());	
//		int total1= time2-time1;
//		String d1= String.valueOf(total1);	
//		row1[2]= "2";
//		row1[3]= object1.getCity6_Desti();
//		row1[4]= object1.getTime6_arrival();
//		model.addRow(row1);
//		
//		
//		Object[] row2= new Object[5];
//		Local object2= new Local();		
//		int t1= Integer.parseInt(object2.getTime2_depar());
//		int t2= Integer.parseInt(object2.getTime7_arrival());
//		int total2= t2-t1;
//		String d2= String.valueOf(total2);
//		row2[0]= object2.getCity2_Depar();
//		row2[1]= object2.getTime2_depar();
//		row2[2]=d2;
//		row2[3]= object2.getCity7_Desti();
//		row2[4]= object2.getTime7_arrival();
//		model.addRow(row1);
//		
//		Object[] row3= new Object[5];
//		Local object3= new Local();
//		row3[0]= object3.getCity3_Depar();
//		row3[1]= object3.getTime3_depar();
//		row3[2]= "2";
//		row3[3]= object3.getCity8_Desti();
//		row3[4]= object3.getTime8_arrival();
//		model.addRow(row3);
//		
//		Object[] row4= new Object[5];
//		Local object4= new Local();
//		row4[0]= object4.getCity4_Depar();
//		row4[1]= object4.getTime4_depar();
//		row4[2]= "2";
//		row4[3]= object4.getCity9_Desti();
//		row4[4]= object4.getTime9_arrival();
//		model.addRow(row4);
//		
//		Object[] row5= new Object[5];
//		Local object5= new Local();
//		row5[0]= object5.getCity5_Depar();
//		row5[1]= object5.getTime5_depar();
//		row5[2]= "2";
//		row5[3]= object5.getCity10_Desti();
//		row5[4]= object5.getTime10_arrival();
//		model.addRow(row5);
//		
//		
		
		
		
		scrollPane.setViewportView(table1);
		//Cart c= new Cart();
		btnNewButton = new JButton("Yes");
		btnNewButton.setBackground(new Color(175, 238, 238));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				Cart c= new Cart();
				if(table1.isRowSelected(0))
				{
					JOptionPane.showMessageDialog(null, Local.getCity2_Desti()+ " is Selected as Destination ");
					
					//TableModel model= table.getModel();
					String depart= Local.getDestination_city2();
					String depar_time= Local.getTime1_depar();
					String D1= Local.getDuration();
					String Desti= Local.getCity2_Desti();
					String desti_time= Local.getTime1_arrival();
					c.pass(depart,depar_time, D1, Desti, desti_time);
					c.setVisible(true);
					dispose();
					
				}
				else if(table1.isRowSelected(1))
				{
					JOptionPane.showMessageDialog(null, Local.getCity3_Desti()+ " is Selected as Destination");
					String depart=Local.getDestination_city2();
					String depart_time=Local.getTime2_depar();
					String D2=Local.getDuration();
					String Destina=Local.getCity3_Desti();
					String Desti_time=Local.getTime2_arrival();
					c.pass(depart,depart_time, D2, Destina, Desti_time);
					c.setVisible(true);
					dispose();
					
					
				}
				else if(table1.isRowSelected(2))
				{
					JOptionPane.showMessageDialog(null, Local.getCity5_Desti()+  " is Selected ");
					String depart= Local.getDestination_city2();
					
					String depart_time=Local.getTime3_depar();
					String D2=Local.getDuration();
					String Destina=Local.getCity5_Desti();
					String Desti_time=Local.getTime3_arrival();
					c.pass(depart,depart_time, D2, Destina, Desti_time);
					c.setVisible(true);
					dispose();
				}
				else if(table1.isRowSelected(3))
				{
					JOptionPane.showMessageDialog(null, Local.getCity6_Desti() +" is Selected");
					String depart=Local.getDestination_city2();
					String depart_time=Local.getTime4_depar();
					String D2=Local.getDuration();
					String Destina=Local.getCity6_Desti();
					String Desti_time=Local.getTime4_arrival();
					c.pass(depart,depart_time, D2, Destina, Desti_time);
					c.setVisible(true);
					dispose();
				}
				else if(table1.isRowSelected(4))
				{
					JOptionPane.showMessageDialog(null, Local.getCity7_Desti() + " is Selected");
					String depart=Local.getDestination_city2();
					String depart_time=Local.getTime5_depar();
					String D2=Local.getDuration();
					String Destina=Local.getCity7_Desti();
					String Desti_time=Local.getTime6_arrival();
					c.pass(depart,depart_time, D2, Destina, Desti_time);
					c.setVisible(true);
					dispose();
				}
				else if(table1.isRowSelected(5))
				{
					JOptionPane.showMessageDialog(null, Local.getCity8_Desti() + " is Selected");
					String depart=Local.getDestination_city2();
					String depart_time=Local.getTime6_depar();
					String D2="2";
					String Destina=Local.getCity8_Desti();
					String Desti_time=Local.getTime6_arrival();
					c.pass(depart,depart_time, D2, Destina, Desti_time);
					c.setVisible(true);
					dispose();
				}
				else if(table1.isRowSelected(6))
				{
					JOptionPane.showMessageDialog(null, Local.getCity10_Desti() + " is Selected");
					String depart=Local.getDestination_city();
					String depart_time=Local.getTime7_depar();
					String D2=Local.getDuration();
					String Destina=Local.getCity10_Desti();
					String Desti_time=Local.getTime7_arrival();
					c.pass(depart,depart_time, D2, Destina, Desti_time);
					c.setVisible(true);
					dispose();
				}
				else if(table1.isRowSelected(7))
				{
					JOptionPane.showMessageDialog(null, Local.getCity4_Desti() + " is Selected");
					String depart=Local.getDestination_city2();
					String depart_time=Local.getTime8_depar();
					String D2=Local.getDuration();
					String Destina=Local.getCity4_Desti();
					String Desti_time=Local.getTime8_arrival();
					c.pass(depart,depart_time, D2, Destina, Desti_time);
					c.setVisible(true);
					dispose();
				}
				else if(table1.isRowSelected(8))
				{
					JOptionPane.showMessageDialog(null, Local.getCity2_Desti() + " is Selected");
					String depart=Local.getDestination_city2();
					String depart_time=Local.getTime9_depar();
					String D2=Local.getDuration();
					String Destina=Local.getCity2_Desti();
					String Desti_time=Local.getTime9_arrival();
					c.pass(depart,depart_time, D2, Destina, Desti_time);
					c.setVisible(true);
					dispose();
				}
				else if(table1.isRowSelected(9))
				{
					JOptionPane.showMessageDialog(null, Local.getCity3_Desti() + " is Selected");
					String depart=Local.getDestination_city2();
					String depart_time=Local.getTime10_depar();
					String D2=Local.getDuration();
					String Destina=Local.getCity3_Desti();
					String Desti_time=Local.getTime10_arrival();
					c.pass(depart,depart_time, D2, Destina, Desti_time);
					c.setVisible(true);
					dispose();
				}
			}
		});
		btnNewButton.setBounds(254, 291, 89, 23);
		contentPane.add(btnNewButton);
		
		lblNewLabel = new JLabel("Select the City You want to travel");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setForeground(new Color(165, 42, 42));
		lblNewLabel.setBounds(10, 11, 452, 23);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Do you want to reserve the Seat:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1.setBounds(10, 232, 230, 25);
		contentPane.add(lblNewLabel_1);
		
		btnNewButton_1 = new JButton("No");
		btnNewButton_1.setBackground(new Color(175, 238, 238));
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				JOptionPane.showMessageDialog(null, "Thanks for visiting");
				Details d= new Details();
				d.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(436, 291, 89, 23);
		contentPane.add(btnNewButton_1);
		
		Back_button = new JButton("BACK");
		Back_button.setBackground(new Color(95, 158, 160));
		Back_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				PassengerOption option= new PassengerOption();
				option.setVisible(true);
				dispose();
			}
		});
		Back_button.setBounds(53, 377, 89, 23);
		contentPane.add(Back_button);
		
		
//		admin.addarraylist_oflocal(object1);
//		admin.addarraylist_oflocal(object2);
//		admin.addarraylist_oflocal(object3);
//		admin.addarraylist_oflocal(object4);
//		admin.addarraylist_oflocal(object5);
//		
		
		
	}

}
	

