package presentation_layer;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Adminsign extends JFrame {

	private JPanel contentPane;
	private JTextField text1;
	private JPasswordField password;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Adminsign frame = new Adminsign();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Adminsign() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("LOGIN IN");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setBounds(138, 11, 96, 28);
		contentPane.add(lblNewLabel);
		
		password = new JPasswordField();
		password.setBounds(108, 163, 156, 20);
		contentPane.add(password);
		
		JLabel lblNewLabel_1 = new JLabel("Name:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(30, 51, 87, 20);
		contentPane.add(lblNewLabel_1);
		
		text1 = new JTextField();
		text1.setBounds(108, 82, 156, 20);
		contentPane.add(text1);
		text1.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Password:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2.setBounds(30, 132, 102, 20);
		contentPane.add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("Sign In");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e)
			{
				String name= "iqra";
				String pass="1234";
				if(text1.getText().equals(name) && password.getText().equals(pass))
				{
					JOptionPane.showMessageDialog(null, "Successfully Login");
					Adminoption city= new Adminoption();
					city.setVisible(true);
					dispose();
//					AdminUpadateClass update = new AdminUpadateClass();
//					update.setVisible(true);
//					dispose();
				}
				else
				{
					JOptionPane.showMessageDialog(null, "Invalid Password and username");
				}
			}
		});
		btnNewButton.setBounds(335, 227, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("BACK");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				Menu m= new Menu();
				m.setVisible(true);
				dispose();
				
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_1.setBounds(10, 227, 89, 23);
		contentPane.add(btnNewButton_1);
		
		
	}

}
