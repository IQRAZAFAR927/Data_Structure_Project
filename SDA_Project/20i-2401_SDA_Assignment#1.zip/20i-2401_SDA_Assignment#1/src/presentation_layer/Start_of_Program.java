package presentation_layer;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import business_layer.Nonregisteruser;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JLabel;
import java.awt.Color;

public class Start_of_Program extends JFrame {

	private JPanel contentPane;
	private final JButton RigesterUser = new JButton("Register User");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Start_of_Program frame = new Start_of_Program();
					frame.setVisible(true);
					frame.setTitle("Registration ");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Start_of_Program() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 255, 255));
		contentPane.setForeground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		RigesterUser.setBackground(new Color(135, 206, 235));
		RigesterUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
			}
		});
		RigesterUser.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				Menu m= new Menu();
				m.setVisible(true);
				dispose();
			}
		});
		RigesterUser.setBounds(46, 111, 120, 31);
		contentPane.add(RigesterUser);
		
		JButton Nonregister = new JButton("Non-Register User");
		Nonregister.setBackground(new Color(135, 206, 235));
		Nonregister.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				Nonregisteruser non= new Nonregisteruser();
				non.setVisible(true);
				dispose();
			}
		});
		Nonregister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		Nonregister.setBounds(247, 113, 149, 29);
		contentPane.add(Nonregister);
		
		JLabel lblNewLabel = new JLabel("Welcome to NPAFS System");
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setBounds(59, 25, 255, 31);
		contentPane.add(lblNewLabel);
	}
}
