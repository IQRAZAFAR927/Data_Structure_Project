package presentation_layer;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import business_layer.Inter_isl_north;
import business_layer.Islamabad_northairport;
import business_layer.Islamabad_southairport;
import business_layer.inter_isl_south;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import java.awt.Color;

public class PassengerOption extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PassengerOption frame = new PassengerOption();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PassengerOption() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel City = new JLabel("Please Selected the City:");
		City.setFont(new Font("Tahoma", Font.BOLD, 14));
		City.setBounds(26, 24, 215, 26);
		contentPane.add(City);
		
		
		
		
		JLabel cityname = new JLabel("");
		cityname.setFont(new Font("Tahoma", Font.BOLD, 11));
		cityname.setBounds(26, 139, 130, 26);
		contentPane.add(cityname);
		
		JLabel Direction_name = new JLabel("");
		Direction_name.setBounds(176, 140, 136, 24);
		contentPane.add(Direction_name);
		
		JLabel Airporttype = new JLabel("");
		Airporttype.setFont(new Font("Tahoma", Font.BOLD, 12));
		Airporttype.setBounds(325, 139, 99, 26);
		contentPane.add(Airporttype);
		
		String[] City1= {"City","Islamabad", "Lahore", "Quetta", "Peshawar", "Karachi"};
		String[] Direction1= {"Direction","North", "South"};
		String[] Type1= {"Type","Local", "International"};
		
		JComboBox c = new JComboBox(City1);
		c.setForeground(new Color(0, 0, 255));
		c.setBackground(new Color(240, 248, 255));
		c.setBounds(26, 83, 130, 26);
		contentPane.add(c);
		

		JComboBox d = new JComboBox(Direction1);
		d.setForeground(new Color(0, 0, 255));
		d.setBackground(new Color(240, 248, 255));
		d.setBounds(182, 85, 130, 24);
		contentPane.add(d);
		
		JComboBox t = new JComboBox(Type1);
		t.setBackground(new Color(240, 248, 255));
		t.setForeground(new Color(0, 0, 255));
		t.setBounds(332, 85, 92, 24);
		contentPane.add(t);
		
		JButton go = new JButton("Submit");
		go.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				if( (c.getSelectedIndex()==1)  && (d.getSelectedIndex()==1) && (t.getSelectedIndex()==1)) 
				{
					
					
					Islamabad_northairport isl= new Islamabad_northairport();
					isl.setVisible(true);
					dispose();
							
				}
				else if( (c.getSelectedIndex()==1)  && (d.getSelectedIndex()==2) && (t.getSelectedIndex()==1)) 
				{
					
					
					Islamabad_southairport isl= new Islamabad_southairport();
					isl.setVisible(true);
					dispose();
							
				}
				else if( (c.getSelectedIndex()==1)  && (d.getSelectedIndex()==1) && (t.getSelectedIndex()==2)) 
				{
					
					
					Inter_isl_north isl= new Inter_isl_north();
					isl.setVisible(true);
					dispose();
							
				}
				else if( (c.getSelectedIndex()==1)  && (d.getSelectedIndex()==2) && (t.getSelectedIndex()==2)) 
				{
					
					
				inter_isl_south isl= new inter_isl_south();
					isl.setVisible(true);
					dispose();
							
				}
				
				else if( (c.getSelectedIndex()==2)  && (d.getSelectedIndex()==1) && (t.getSelectedIndex()==1)) 
				{
					
					
					Lahore_northairport lahore= new Lahore_northairport();
					lahore.setVisible(true);
					dispose();
							
				}
				else if( (c.getSelectedIndex()==2)  && (d.getSelectedIndex()==2) && (t.getSelectedIndex()==1)) 
				{
					
					
					Lahore_southairport lahore= new Lahore_southairport();
					lahore.setVisible(true);
					dispose();
							
				}
				
				else if( (c.getSelectedIndex()==4)  && (d.getSelectedIndex()==1) && (t.getSelectedIndex()==1)) 
				{
					
					
					Peshawr_northairport isl= new Peshawr_northairport();
					isl.setVisible(true);
					dispose();
							
				}
				else if( (c.getSelectedIndex()==4)  && (d.getSelectedIndex()==2) && (t.getSelectedIndex()==1)) 
				{
					
					
					Peshawar_southairport isl= new Peshawar_southairport();
					isl.setVisible(true);
					dispose();
							
				}
				else if( (c.getSelectedIndex()==3)  && (d.getSelectedIndex()==1) && (t.getSelectedIndex()==1)) 
				{
					
					
					Quetta_northairport isl= new Quetta_northairport ();
					isl.setVisible(true);
					dispose();
							
				}
				else if( (c.getSelectedIndex()==3)  && (d.getSelectedIndex()==2) && (t.getSelectedIndex()==1)) 
				{
					
					
					Quetta_southairport  isl= new Quetta_southairport ();
					isl.setVisible(true);
					dispose();
							
				}
				else if( (c.getSelectedIndex()==5)  && (d.getSelectedIndex()==1) && (t.getSelectedIndex()==1)) 
				{
					
					
					Karachi_northairport isl= new Karachi_northairport  ();
					isl.setVisible(true);
					dispose();
							
				}
				else if( (c.getSelectedIndex()==5)  && (d.getSelectedIndex()==2) && (t.getSelectedIndex()==1)) 
				{
					
					
					Karachi_southairport  isl= new Karachi_southairport();
					isl.setVisible(true);
					dispose();
							
				}
				
			}
		});
		go.setBounds(345, 211, 89, 23);
		contentPane.add(go);
		
		JButton btnNewButton = new JButton("BACK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				Menu m= new Menu();
				m.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton.setBounds(10, 211, 89, 23);
		contentPane.add(btnNewButton);
		
		
		
		
		
		
	
		
		
				
		
	}
}
