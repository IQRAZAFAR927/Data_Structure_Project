package presentation_layer;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import business_layer.Cart;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;

public class Confirmation extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Confirmation frame = new Confirmation();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void total_attain(double total, int number)
	{
		JLabel lblNewLabel_1 = new JLabel("GrandTotal:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(20, 50, 92, 26);
		contentPane.add(lblNewLabel_1);
		
		String t= Double.toString(total);
		JLabel TOTAL = new JLabel(t);
		TOTAL.setBounds(137, 57, 103, 19);
		contentPane.add(TOTAL);
		
		JLabel lblNewLabel_4 = new JLabel("Total Seats:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_4.setBounds(25, 210, 92, 19);
		contentPane.add(lblNewLabel_4);
		
		String num= String.valueOf(number);
		JLabel Seat_number = new JLabel(num);
		Seat_number.setBounds(127, 190, 113, 34);
		contentPane.add(Seat_number);
		
		

		
		
	}
	public void setter(String D1, String D2)
	{
		JLabel lblNewLabel_3 = new JLabel("Depart:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_3.setBounds(20, 99, 72, 26);
		contentPane.add(lblNewLabel_3);
		
		JLabel Name = new JLabel(D1);
		Name.setBounds(127, 106, 92, 19);
		contentPane.add(Name);
		
		JLabel lblNewLabel_2 = new JLabel("Desti #:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2.setBounds(20, 153, 92, 26);
		contentPane.add(lblNewLabel_2);
		
		
		JLabel CNIC = new JLabel(D2);
		CNIC.setBounds(140, 153, 100, 26);
		contentPane.add(CNIC);
	}
	
	
	/**
	 * Create the frame.
	 */
	public Confirmation() 
	{
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 521, 424);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Bookings Details");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(127, 11, 139, 26);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_5 = new JLabel("Your Seat has been booked.Thanks!");
		lblNewLabel_5.setForeground(new Color(255, 69, 0));
		lblNewLabel_5.setBackground(new Color(240, 248, 255));
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_5.setBounds(127, 320, 326, 42);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_4 = new JLabel("Seat #:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_4.setBounds(25, 210, 92, 19);
		contentPane.add(lblNewLabel_4);
		
		//String num= String.valueOf();
		JLabel Seat_number = new JLabel();
		Seat_number.setBounds(96, 205, 113, 34);
		contentPane.add(Seat_number);
		
		JButton btnNewButton = new JButton("BACK");
		btnNewButton.setBackground(new Color(95, 158, 160));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e)
			{
				Cart c= new Cart();
				c.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton.setBounds(10, 351, 89, 23);
		contentPane.add(btnNewButton);
	}
}
