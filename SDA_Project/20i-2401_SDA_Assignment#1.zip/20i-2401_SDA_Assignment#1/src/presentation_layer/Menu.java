package presentation_layer;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import business_layer.Signin;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JLabel;
import java.awt.Color;

public class Menu extends JFrame {

	private JPanel contentPane;
	private JLabel lblNewLabel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu frame = new Menu();
					frame.setVisible(true);
					frame.setTitle("Menu");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Menu() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton passenger_button = new JButton("Passenger");
		passenger_button.setBackground(new Color(135, 206, 235));
		passenger_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e)
			{
				Signin obj= new Signin();
				obj.setVisible(true);
				dispose();
			}
		});
		passenger_button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		passenger_button.setBounds(64, 152, 104, 23);
		contentPane.add(passenger_button);
		
		JButton Admin_button = new JButton("Admin");
		Admin_button.setBackground(new Color(135, 206, 235));
		Admin_button.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				Adminsign update= new Adminsign();
				update.setVisible(true);
				dispose();
			}
		});
		Admin_button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		Admin_button.setBounds(238, 152, 89, 23);
		contentPane.add(Admin_button);
		
		lblNewLabel = new JLabel("Please Select the Option");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setBounds(83, 65, 169, 23);
		contentPane.add(lblNewLabel);
		
		JButton back = new JButton("Back");
		back.setBackground(new Color(192, 192, 192));
		back.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				Start_of_Program backoption= new Start_of_Program();
				backoption.setVisible(true);
				dispose();
			}
		});
		back.setBounds(22, 227, 89, 23);
		contentPane.add(back);
	}
}
