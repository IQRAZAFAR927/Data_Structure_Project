package presentation_layer;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import business_layer.Admin_Islamabadnorth;
import business_layer.Admin_isl_inter_north;
import business_layer.Islamabad_southairport;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Adminoption extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Adminoption frame = new Adminoption();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Adminoption() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		String[]city= {"Islamabad", "Lahore", "Quetta", "Peshawar", "Karachi"};
		
		JLabel lblNewLabel = new JLabel("City you want to update the booking:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setBounds(44, 34, 282, 22);
		contentPane.add(lblNewLabel);
		
		String[] City1= {"City","Islamabad", "Lahore", "Quetta", "Peshawar", "Karachi"};
		String[] Direction1= {"Direction","North", "South"};
		String[] Type1= {"Type","Local", "International"};
		
		JComboBox City = new JComboBox(City1);
		City.setBounds(10, 101, 89, 23);
		contentPane.add(City);
		
		JComboBox d = new JComboBox(Direction1);
		d.setBounds(142, 101, 116, 23);
		contentPane.add(d);
		
		JComboBox t = new JComboBox(Type1);
		t.setBounds(308, 101, 89, 23);
		contentPane.add(t);
		
		JButton btnNewButton = new JButton("CONTINUE");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				if( (City.getSelectedIndex()==1)  && (d.getSelectedIndex()==1) && (t.getSelectedIndex()==1)) 
				{
					Admin_Islamabadnorth north= new Admin_Islamabadnorth();
					north.setVisible(true);
					dispose();			
				}
				else if( (City.getSelectedIndex()==1)  && (d.getSelectedIndex()==2) && (t.getSelectedIndex()==1)) 
				{
					Islamabad_southairport isl= new Islamabad_southairport();
					isl.setVisible(true);
					dispose();			
				}
				else if( (City.getSelectedIndex()==1)  && (d.getSelectedIndex()==1) && (t.getSelectedIndex()==2)) 
				{
					Admin_isl_inter_north isl= new Admin_isl_inter_north();
					isl.setVisible(true);
					dispose();			
				}
				else if( (City.getSelectedIndex()==1)  && (d.getSelectedIndex()==2) && (t.getSelectedIndex()==2)) 
				{
					Admin_isl_inter_north isl= new Admin_isl_inter_north();
					isl.setVisible(true);
					dispose();			
				}
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton.setBounds(308, 228, 116, 22);
		contentPane.add(btnNewButton);
		
		JButton back = new JButton("BACK");
		back.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				Adminsign sign= new Adminsign();
				sign.setVisible(true);
				dispose();
			}
		});
		back.setFont(new Font("Tahoma", Font.BOLD, 12));
		back.setBounds(10, 229, 89, 23);
		contentPane.add(back);
		
		
		
	}
}
