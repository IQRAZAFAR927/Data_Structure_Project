package presentation_layer;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import business_layer.Signin;

import javax.swing.JRadioButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JLabel;
import java.awt.Color;

public class Details extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Details frame = new Details();
					frame.setVisible(true);
					frame.setTitle("Details Page");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Details() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JRadioButton Sehedule = new JRadioButton("Continues");
		Sehedule.setBackground(new Color(240, 248, 255));
		Sehedule.setFont(new Font("Tahoma", Font.BOLD, 13));
		Sehedule.setForeground(new Color(0, 0, 0));
		Sehedule.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e)
			{
				
				PassengerOption option= new PassengerOption();
				option.setVisible(true);
				dispose();
//				Cities city= new Cities();
//				city.setVisible(true);
//				dispose();
//				TypeofAirport type = new TypeofAirport();
//				type.setVisible(true);
//				dispose();
			}
		});
		Sehedule.setBounds(96, 117, 109, 23);
		contentPane.add(Sehedule);
		
		JButton Backmenu = new JButton("Back ");
		Backmenu.setBackground(new Color(95, 158, 160));
		Backmenu.setFont(new Font("Tahoma", Font.BOLD, 13));
		Backmenu.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e)
			{
				Signin backoption= new Signin();
				backoption.setVisible(true);
				dispose();
			}
		});
		Backmenu.setBounds(10, 227, 91, 23);
		contentPane.add(Backmenu);
		
		JLabel lblNewLabel = new JLabel("To View, Reserve and cancel the seat. Press Continue:");
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setBounds(10, 40, 381, 51);
		contentPane.add(lblNewLabel);
	}
}
