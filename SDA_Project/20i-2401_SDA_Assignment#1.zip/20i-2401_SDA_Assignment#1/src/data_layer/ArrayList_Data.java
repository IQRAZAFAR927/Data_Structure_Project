package data_layer;

import java.util.ArrayList;
import business_layer.Bookings;
import business_layer.Local;
import business_layer.Passenger;
import business_layer.Flights;

public class ArrayList_Data 
{
	public ArrayList <Bookings> booking= new ArrayList <Bookings>();
	//ArrayList <Bookings> booking= new ArrayList <Bookings>();
	ArrayList <Local> local= new ArrayList<Local>();
	public  ArrayList <Flights> flight= new ArrayList <Flights>();
	public  ArrayList <Passenger> passenger_Details = new ArrayList<>();
	//static ArrayList <Passenger> passenger_Details = new ArrayList<>();
}
