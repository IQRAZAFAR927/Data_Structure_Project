package DSproject;
import java.util.Arrays;

public class Queue {

    public node[] array;
    private int front;
    private int rear;
    public int size;
    
    public Queue(node[] array, int size) {
		super();
		this.array = array;
		this.size = size;
		front=rear=-1;
	}

	public Queue(int size){
        this.size = size;
        this.array = new node[size];
        front=-1;
        rear=-1;
    }
    
    public Queue(){
        this.array = new node[0];
        front=rear=-1;
    }

    public void printQueue(){
        for(int i=front ; i <= rear ; i++)
            System.out.println(i+" "+array[i].getData());
    }

    public void enqueue(node element){
        if(isEmpty()){
            array[++front] = element;
            rear++;
        }
        else if(isFull()){
            System.out.println("Already Full");
        }else
            array[++rear]=element;
    }

    public node dequeue(){
        node temp = array[front];
        if(isEmpty()) {
            System.out.println("Already Empty!");
            return null;
        }
        else {
            array[front] = null;
            front++;
        }
        return temp;
    }

    public node peek(){
        return array[front];
    }

    public boolean isEmpty(){
        return front == rear && front == -1;
    }

    public boolean isFull(){
        return rear == array.length-1 ;
    }

    public node getRearObject(){
        return  array[rear];
    }

    public void setFrontObject(node front){
        array[this.front] = front;
    }

    public void setRearObject(node rear){
        array[this.rear] = rear;
    }

    public int getFront() {
        return front;
    }

    public int getRear() {
        return rear;
    }

    public Object[] getArray() {
        return array;
    }

    public void setArray(node[] array) {
        this.array = array;
    }

    public void setFront(int front) {
        this.front = front;
    }

    public void setRear(int rear) {
        this.rear = rear;
    }

    void sort()
    {
        int n = array.length;

        // One by one move boundary of unsorted subarray
        for (int i = front; i < n-1; i++)
        {
            // Find the minimum element in unsorted array
            int min_idx = i;
            for (int j = i+1; j < n; j++)
                if (array[j].getFrequency() < array[min_idx].getFrequency())
                    min_idx = j;

            // Swap the found minimum element with the first
            // element
            node temp = array[min_idx];
            array[min_idx] = array[i];
            array[i] = temp;
        }
    }
    public node replace(node element){
        node temp = array[front];
        array[front] = element;
        return temp;
    }

	


}
