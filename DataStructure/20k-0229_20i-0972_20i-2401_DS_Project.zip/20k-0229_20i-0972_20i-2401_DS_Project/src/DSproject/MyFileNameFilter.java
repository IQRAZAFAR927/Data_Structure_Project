package DSproject;
import java.io.File;
import java.io.FilenameFilter;

public class MyFileNameFilter implements FilenameFilter {

	String initials;
	
	
	public MyFileNameFilter(String initials) {
		super();
		this.initials = initials;
	}


	@Override
	public boolean accept(File dir, String name) {
		
		return name.startsWith(initials);
	}

}
