package DSproject;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class main 
{
	static Queue Q;
	static int size;
	static node[]nood;
	static node []need;
	static String original="beep boop beer!";
	static String originalbinary="";
	static int Osizebinary;
	static String parts="";
	static String laterusestring="";
	static void frequency()
	{
		for(int i=0;i<original.length();i++)
		{
			
		}
	}
	static int printCharWithFreq(String str)
	{    
	      int[] freq = new int[str.length()];    
	        int i, j;     
	       char string[] = str.toCharArray();    
	            
	        for(i = 0; i <str.length(); i++) 
	        {    
	            freq[i] = 1;    
	            for(j = i+1; j <str.length(); j++) {    
	                if(string[i] == string[j]) {
	                	
	                    freq[i]++;   
	                    string[j] = '0';    
	                }    
	            }    
	        }
	        System.out.println("Characters and their corresponding frequencies"); 
	       
	        System.out.println("\n\t Character"+ "\t"+"Frequencey");
	        System.out.println("\t-------------"+ "\t"+"----------");
	        int count=0;
	        for(i = 0; i <freq.length; i++) 
	        {    
	        	
	            if(string[i] != '0')  
	            {
	            	if(string[i]==' ')
	            	{
	            		
	            		System.out.println("\t"+"Space" + "\t\t" + freq[i]);
	            	}
	            	else
	            	{
	                System.out.println("\t"+string[i] + "\t\t" + freq[i]);
	            	}
	                count++;
	                
	            }
	       }
	        System.out.println("\t---------------------------");
	        return count;
	}
	
	static node[] makeoriginalnode(String str,int freak)
	{
			node n1[]=new node[freak];
			for(int i = 0;i<freak;i++)
			{
				 n1[i]= new node();
			}
	        int[] freq = new int[str.length()];    
	        int i, j;     
	        char string[] = str.toCharArray();    
	            
	        for(i = 0; i <str.length(); i++) 
	        {    
	            freq[i] = 0;    
	            for(j = 0; j <str.length(); j++) {    
	                if(string[i] == string[j]) {    
	                    freq[i]++;   
	                       
	                }    
	            }    
	        }
	        for(i = 0; i <freq.length; i++) 
	        {    
	        	n1[i].setData(string[i]);
	        	n1[i].setFrequency(freq[i]);
	        	if(n1[i].getData()==' ')
	        	{
	        		System.out.println("\t"+"Space"+ " \t\t"+n1[i].getFrequency());
	        		
	        	}else
	        	{
	        	System.out.println("\t"+n1[i].getData()+ " \t\t"+n1[i].getFrequency());}
	       }
	        return n1;
	}
	
	static node[] insertnodeinqueue(String str,int freak)
	{
			node n[]=new node[freak];
			for(int i = 0;i<freak;i++)
			{
				 n[i]= new node();
			}
	        int[] freq = new int[str.length()];    
	        int i, j;     
	        char string[] = str.toCharArray();    
	            
	        for(i = 0; i <str.length(); i++) 
	        {    
	            freq[i] = 1;    
	            for(j = i+1; j <str.length(); j++) {    
	                if(string[i] == string[j]) {    
	                    freq[i]++;   
	                    string[j] = '0';    
	                }    
	            }    
	        }
	        int count1=0;
	        for(i = 0; i <freq.length; i++) 
	        {    
	        
	            if(string[i] != '0')  
	            {
	                n[count1].setData(string[i]);
	                n[count1].setFrequency(freq[i]);
	                count1++;
	            }
	       }
	        return n;
	} 
	static void getbinary(node root)
	{	int count1=0;
		for(int i=0;i<size;i++)
		{
			
			if(root.getData()==nood[count1].getData())
			{
				nood[count1].binary=root.binary;
			}
			count1++;
		}
		
	}
	
	public static void finduniquecharacter(String inputstring)
	{
		for(int i=0; i<inputstring.length();i++)
		{
			int flag=0;
			for(int j=0; j<inputstring.length();j++)
			{
				if(inputstring.charAt(i)==inputstring.charAt(j)&& i!=j)
				{
					flag=1;
					break;
				}
			}
			if(flag==0)
			{
				System.out.println(inputstring.charAt(i));
			}
		}
	}
	public static void printTree(node root) 
	{
		{
			if (root!=null)
			{
				
				System.out.println("\t"+root.getData() + " " + root.binary);
				getbinary(root);
				printTree(root.getLeft());
				printTree(root.getRight());
			}
		}
	}
	
	static void strToBinary(String s)
	{
	        int n = s.length();
	 
	        for (int i = 0; i < n; i++)
	        {
	            int val = Integer.valueOf(s.charAt(i));
	            String bin = "";
	            while (val > 0)
	            {
	                if (val % 2 == 1)
	                {
	                    bin += '1';
	                    Osizebinary++;
	                }
	                else
	                    bin += '0';
	                val /= 2;
	                Osizebinary++;
	            }
	            bin = reverse(bin);
	            originalbinary=originalbinary+' '+bin;
	            System.out.print(  need[i].binary=bin+" ");
	        }
	 }
	
	 static String reverse(String input)
	 {
	        char[] a = input.toCharArray();
	        int l, r = 0;
	        r = a.length - 1;
	 
	        for (l = 0; l < r; l++, r--)
	        {
	            char temp = a[l];
	            a[l] = a[r];
	            a[r] = temp;
	        }
	        return String.valueOf(a);
	}
	 
	 public static void divideintoparts(String str) throws IOException
	 {
		 ArrayList <Character> data1= new ArrayList<Character>();
		 ArrayList <String> freq= new ArrayList<String>();
		 ArrayList <String> data= new ArrayList<String>();
		 String save="";
		 for(int i =0;i<nood.length;i++)
	     {
			 freq.add(nood[i].binary);
			 data1.add(nood[i].getData());	 
		 }
		int [] mainstring= new int[str.length()];
		for(int i=0; i<str.length();i++)
		{
			char c= str.charAt(i);
			for(int j=0; j<data1.size();j++)
			{
				if(c==data1.get(j))
				{
						mainstring[i]=j;
				}
			}
		}
		for(int k=0; k<mainstring.length;k++)
		{		
				String j=freq.get(mainstring[k]);
				data.add(j);
		}
		 for(int print=0; print<data.size();print++)
		{
				String p=data.get(print);
				save+=p;
		}
		 System.out.println("\tBinary Value  | ASCI Value  | Character");
		 System.out.println("\t---------------------------------------");
		   
		ArrayList <String> finalstring= new ArrayList<String>(); 
		ArrayList <Integer> finaldecimal= new ArrayList<Integer>();
		ArrayList <Character> finalchar= new ArrayList<Character>();
		
		 Pattern pattern = Pattern.compile(".{1," + 7 + "}");
         Matcher matcher = pattern.matcher(save);
         while (matcher.find()) 
         {
             String part = save.substring(matcher.start(), matcher.end());
             if(part.length()<7)
             {
            	 while(part.length()!=7)
            	 {
            		 part+=0;
            	 }
             }
             finalstring.add(part);
         }
         for(int f=0; f<finalstring.size();f++)
         {
        	 String deci=finalstring.get(f);
        	 if(deci.length()<7)
        	 {
        		 while(deci.length()!=7)
        		 {
        			 deci+=0;
        		 } 
        	 }
        	 int decimal=Integer.parseInt(deci,2);
        	 finaldecimal.add(decimal);
         }
   
         for(int g=0; g<finaldecimal.size();g++)
         {
        	 int ch=finaldecimal.get(g);
        	 char c=(char)ch;
        	 finalchar.add(c);
         } 
         for(int print=0;print<finalstring.size();print++ )
         {
        	 String finalbinaryoutput= finalstring.get(print);
        	 Integer finalasciioutput=  finaldecimal.get(print);
        	 char finalcharoutput= finalchar.get(print);
        	 String convert= String.valueOf(finalcharoutput);
        	 char[] stringintocher= convert.toCharArray();
        	 for(int c=0; c<stringintocher.length;c++)
        	 {
        		 laterusestring+=stringintocher[c];
        	 }
        	 //laterusestring=convert;
//        	 fileOperations fileobj= new fileOperations();
//        	 fileobj.writeOnFile("encoded", convert);
        	
        	 if(finalasciioutput==31)
        	 {
        	 System.out.println("\t"+finalbinaryoutput+ "\t      |"+ finalasciioutput+ "\t    |"+"Unit Separator" );
        	
        	 }
        	 else
        	 {
        		 System.out.println("\t"+finalbinaryoutput+ "\t      |"+ finalasciioutput+ "\t    |"+finalcharoutput );
        		 //fileOperations fileobj= new fileOperations();
             	 //fileobj.writeOnFile("encoded", finalcharoutput);
        	 }
         }
         System.out.println("\t---------------------------------------");
    }  
		
		 
	public static void main(String[] args) throws IOException
    {
		fileOperations fileobj= new fileOperations();
		
		int choice=0;
		String string_input="";

		Scanner input= new Scanner(System.in);
		Scanner sc= new Scanner(System.in);
		do
		{
		System.out.println("\n\t\tWELCOME TO HUFFMAN PROGRAM");
		System.out.println("\t\t|-----------------------------|");
		System.out.println("1.  Extract data from file:");
		System.out.println("2.  Find the size of File: ");
		System.out.println("3.  Find unique Character of file:");
		System.out.println("4.  Find the frequencey of each character: ");
		System.out.println("5.  Print the huffman Tree:");
		System.out.println("6.  Print the huffman table:");
		System.out.println("7. Read the encoding file and size: ");
		System.out.println("8.  Print the original table");
		System.out.println("9. Exit");
		choice=input.nextInt();
		if(choice==1)
		{
			//fileobj.writeOnFile("Original", string_input);
			System.out.println(fileobj.getDataFromFile("Original"));
		}
		else if(choice==2)
		{
//			fileOperations obj= new fileOperations();
//			int filesize=(int) obj.getFileSize("Original");
//			size=printCharWithFreq(original);
//			filesize=filesize*size;
//			System.out.println(filesize);
			 try 
			 {
				 System.out.println("\tData of file: ");
				 String length= fileobj.getDataFromFile("Original");
				 int l= length.length();
		         System.out.println("File length: "+ l*8+ " bits");
		     } catch (Exception e) {
			 		}
		}
		else if(choice==3)
		{
			String s=fileobj.getDataFromFile("Original");
			//System.out.println(s);
			System.out.println("Unique character in file: ");
			finduniquecharacter(s);
			
		}
		
		else if(choice==4)
		{
			
			 int freak=printCharWithFreq(original);
			 size=freak;
			 nood=insertnodeinqueue(string_input,freak);
		}
		else if(choice==5)
		{
			 int freak=printCharWithFreq(original);
			 size=freak;
			 int L=original.length();
			 System.out.println("\n \tAll Frequency");
			 System.out.println("\tCharacter"+ "\t"+ "Frequency");
			 System.out.println("\t---------"+"\t"+"-----------");
		     need=makeoriginalnode(original,L);
		     System.out.println("\t-----------------------------");
		     System.out.println("\nChange Original into binary Number");
			 strToBinary(original);
			 System.out.println();
			 
			 nood=insertnodeinqueue(original,freak);
			 Q=new Queue(nood,freak);
			 huffman huff = new huffman();
			 System.out.println("\n\tHuffman Tree Details");
		     node root = huff.makeTree();
		     nood=insertnodeinqueue(original,freak);
		     System.out.println("\nHuffman Tree with Binary");
		     System.out.println("Binary#"+"     Character");
		     printTree(root);	
		}
		else if(choice==6)
		{			 
			 int freak=printCharWithFreq(original);
			 size=freak;
			 int L=original.length();
			 System.out.println("\n \tAll Frequency");
			 System.out.println("\tCharacter"+ "\t"+ "Frequency");
			 System.out.println("\t---------"+"\t"+"-----------");
		     need=makeoriginalnode(original,L);
		     System.out.println("\t-----------------------------");
		     System.out.println("\nChange Original into binary Number");
			 strToBinary(original);
			 System.out.println();
			 
			 nood=insertnodeinqueue(original,freak);
			 Q=new Queue(nood,freak);
			 huffman huff = new huffman();
			 System.out.println("\n\tHuffman Tree Details");
		     node root = huff.makeTree();
		     nood=insertnodeinqueue(original,freak);
		     System.out.println("\nHuffman Tree with Binary");
		     System.out.println("Binary#"+"     Character");
		     printTree(root);		     
		     String str=fileobj.getDataFromFile("Original");
				divideintoparts(str);
				
		}
		else if(choice==7)
		{
			try 
			 {
				
				fileOperations obj= new fileOperations();
				//obj.clearFile("encoded");
				//obj.deleteFile("encoded");
				//obj.clearFile("encoded");
				obj.createFile("encoded");
				obj.writeOnFile("encoded", laterusestring);
				//System.out.println(laterusestring);
				 laterusestring="";
				 System.out.println("\tData of file: ");
				 String length= fileobj.getDataFromFile("encoded");
				 int l= length.length();
		         System.out.println("File length: "+ l*8+ " bits");
		     } catch (Exception e) {
			 		}
		}
		else if(choice==8)
		{

			function obj=new function();
			String str=fileobj.getDataFromFile("Original");
			//System.out.println(str);
			obj.convertToBinary(str);
			
		}else if(choice==9)
		{
			System.exit(1);
		}
		
		}while(choice!=9);	
		 
		
	    
    }
	
}
