package DSproject;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
public class fileOperations 
{

	String fromFile = "";
	static String parentDirectory = "C:\\Users\\DELL\\Desktop\\University records\\Spring 2022_Semester 4\\Data lab\\20i-2401_Project";
	public void createFile(String name) 
	{
		try {
		      File file = new File(name);
		      if (file.createNewFile()) {
		        System.out.println("File created: " + file.getName());
		      } else {
		        System.out.println("File already exists.");
		      }
		    } catch (IOException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
	}
	
	public void deleteFile(String input) 
	{
		File directory = new File(parentDirectory);
		MyFileNameFilter filter = new MyFileNameFilter(input);
		String[] flist = directory.list(filter);
		if (flist == null) {
            System.out.println("Empty directory or directory does not exists.");
        }
        else 
        {
  
          File fileToDelete;
            for (int i = 0; i < flist.length; i++) 
            {
            	System.out.println(flist[i]+" found");
            	
            	for (String file : flist) 
            	{
            		 
                    //construct the absolute file paths
                    String absoluteFilePath = new StringBuffer(parentDirectory).append(File.separator).append(file).toString();
         
                    //open the files using the absolute file path, and then delete them
                    fileToDelete = new File(absoluteFilePath);
                    boolean isdeleted = fileToDelete.delete();
                    System.out.println("File : " + absoluteFilePath + " was deleted : " + isdeleted);
                }
            	
            }
        }
    }
	
	public void writeOnFile( String fileName, String input) throws IOException {
		BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, false));
		writer.write(System.getProperty("line.separator"));
		writer.write(input);
		writer.close();
	}
	public void clearFile(String filename)
	{
		
		Scanner s = new Scanner(filename);
	    while(s.hasNext()){
	        filename.format(" ");
	    }
	} 
	public void updateFile(String fileName) throws IOException
	{
		BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true));
		writer.write(System.getProperty("line.separator"));
		writer.write("");
		writer.close();
	}

	public String getDataFromFile(String fileName) throws IOException 
	{
		BufferedReader br= new BufferedReader(new FileReader(fileName));

		String a = "";
    String st;
    int i = 0;
    while ((st = br.readLine()) != null) 
    {

    	fromFile = fromFile + st;
        // Print the string
    	 a+= st;
        //System.out.println(st);
        i++;
	}
    
	return a;
	}
	
	 public static void printFileSizeNIO(String fileName) 
	 {

	        Path path = Paths.get(fileName);

	        try {

	            // size of a file (in bytes)
	            long bytes = Files.size(path);
	            System.out.println(String.format("%,d bytes", bytes*7));
	           // System.out.println(String.format("%,d kilobytes", bytes / 1024));

	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	 }
	 
	 public static long getFileSize(String filename) 
	  {
	      File file = new File(filename);
	      if (!file.exists() || !file.isFile()) {
	         System.out.println("File doesn\'t exist");
	         return -1;
	      }
	      return file.length();
	   }
}
	

