package DSproject;

import java.io.IOException;
import java.util.ArrayList;

public class function 
{
	public static void convertToBinary(String string) throws IOException 
	{
		ArrayList<String> binary = new ArrayList<String>();
		
		ArrayList<Character> charcterlist= new ArrayList<Character>();
		
		ArrayList <Integer> charcter_to_asci=new ArrayList<Integer>();
		ArrayList <Integer> decimal=new ArrayList<Integer>();
		
		fileOperations fo = new fileOperations();
		char []charArray = string.toCharArray();
		//int binary[] = new int[2000];
		
		int i = 0;
		String s = "";
		int temp = 0;
		System.out.println("\n      Charcter#|  Binary Value | ASCII Value | char");
		System.out.println("\t---------------------------------");
		for(int k = 0; k < string.length() ; k++) 
		{
				temp = charArray[k];				//Change each character into Integer type
				charcter_to_asci.add(temp);			//Add into ArrayList of character type
		}
		for(int l=0; l<charcter_to_asci.size();l++)
		{
			int t= charcter_to_asci.get(l);
			char c=(char)t;  						//Again change into character
			if(c==' ')
			{
				System.out.print("\tSpace"+ "  |  ");
			}
			else
			{			
				System.out.print("\t"+c+ "      |  ");
			}
			String bin1=Integer.toBinaryString(t);				//Change character into binary number
			
				binary.add(bin1);								// Add into Integers type ArrayLis
				System.out.print(bin1);
				int deci=Integer.parseInt(bin1,2);				//Change into decimal number
				System.out.print("\t| "+deci);
				decimal.add(deci);
				char c1=(char)deci; 							//Change into character number
				if(c1==' ')
				{
					System.out.println("\t| "+ "Space");
					charcterlist.add(c1);						//Add into Character ArrayList
					
				}
				else
				{
				System.out.println("\t| "+ c1);
				charcterlist.add(c1);
				}			
			//bin1="";
		}		

}
}	
