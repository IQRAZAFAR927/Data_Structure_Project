package DSproject;

public class node {
	 	private node next;
	    private Character data;
	    private int frequency;
	    String binary;
	    private node right;

	    private node left;
	    public node()
	    {
	    	
	    }
	    public node(Character data){
	        this.data=data;
	    }

	    public node(Character data,int frequency){
	        this.data=data;
	        this.frequency=frequency;
	    }

	    public Character getData() {
	        return data;
	    }

	    public void setData(Character data) {
	        this.data = data;
	    }

	    public node getNext() {
	        return next;
	    }

	    public void setNext(node next) {
	        this.next = next;
	    }

	    public int getFrequency() {
	        return frequency;
	    }

	    public void setFrequency(int frequency) {
	        this.frequency = frequency;
	    }

	    public node getLeft() {
	        return left;
	    }

	    public node getRight() {
	        return right;
	    }

	    public void setLeft(node left) {
	        this.left = left;
	    }

	    public void setRight(node right) {
	        this.right = right;
	    }
		
		

	    
}
