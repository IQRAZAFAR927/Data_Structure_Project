package DSproject;

import java.util.Arrays;

public class huffman {
		
	 private node root;
	 private node temp;
	 static int[] f;
	 static char[] c;
	    
	    public huffman()
	    {
	    	for(int i=0;i<main.size;i++)
	    	{
	    		main.Q.enqueue(new node(main.nood[i].getData(),main.nood[i].getFrequency()));
	    	}
	    }
	    public Queue getQueue() {
	        return main.Q;
	    }

	    public void setQueue(Queue queue) {
	        main.Q = queue;
	    }

	    public node getRoot() {
	        return root;
	    }

	    public void setRoot(node root) {
	        this.root = root;
	    }

	    public node makeTree()
	    {
	        if(main.Q.getFront()==main.Q.size-1) {
	            root = main.Q.peek();
	            return main.Q.peek();
	        }
	        main.Q.sort();
	        node firstNode = main.Q.dequeue();
	        node secondNode = main.Q.replace(new node('*'));
           System.out.println("\t"+firstNode.getData() + " " + firstNode.getFrequency() + " " + secondNode.getData()+" "+secondNode.getFrequency());
            main.Q.peek().setFrequency(firstNode.getFrequency()+secondNode.getFrequency());
            firstNode.binary="0";
            secondNode.binary="1";
            addToChilds(true,firstNode);
            addToChilds(false,secondNode);
            main.Q.peek().setRight(firstNode);
            main.Q.peek().setLeft(secondNode);
            
	        return makeTree();
	    }
	   
	    public void addToChilds(boolean type, node ptr) 
	    {
	    	if(ptr.getLeft()==null && ptr.getRight()==null) return;
	    		if(type==true) 
	    		{
	    			if(ptr.getLeft()!=null) 
	    			{
	    				String old = ptr.getLeft().binary;
	    				ptr.getLeft().binary="0"+old;
	    			}
	    			if(ptr.getRight()!=null) 
	    			{
	    				String old = ptr.getRight().binary;
	    				ptr.getRight().binary="0"+old;
	    			}
	    		}
	    		else if(type==false) 
	    		{
	    			if(ptr.getLeft()!=null)
	    			{
	    				String old = ptr.getLeft().binary;
	    				ptr.getLeft().binary="1"+old;
	    			}
	    			if(ptr.getRight()!=null)
	    			{
	    				String old = ptr.getRight().binary;
	    				ptr.getRight().binary="1"+old;
	    			}
	    		}
	    		addToChilds(false, ptr.getRight());
	    		addToChilds(true,ptr.getLeft());
	    }
	    
	    
	    
}