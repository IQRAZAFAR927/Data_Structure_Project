package assignment1_20i2401;



public class Pool_linkedlist 
{
	Sector head;
	Sector tail;
	public void Insert_At_Start(int start, int end)
	{
		Sector  newnode= head;
		if(head==null)
		{
			Sector newNode = new Sector(start, end);
			head= newnode;
			tail=newnode;
			//Start=head;
			head.prev=tail;
			tail.next=head;
		}
		else
		{
			Sector temp= head;
			Sector newNode = new Sector(start, end);
			while(temp.next!=head)
			{
				temp=temp.next;
			}		
			newnode.next=head;
			head.prev=newnode;			
			head=newnode;
		}
	}
	public void Insert_At_End(int start, int end)
	{
		Sector End= head;
		if(head==null)
		{
			Sector newnode= new Sector(start,end);
			head=End;
			End.next=head;
			End.prev=head;
		}
		else
		{
			
			Sector newnode= new Sector(start,end);
				tail.next=newnode;
				newnode.prev=tail;
				tail=newnode;
				tail.next= head;
				head.prev=tail;
		}
	}
	
	
	public void print_linkedlist()
	{
		Sector temp= head;
		System.out.println("Nodes of the linked list: ");
			while(temp.next!=head)
			{
				System.out.println(temp.startrange+ "  "+ temp.endrange);
				temp= temp.next;
			}
			temp = tail;
			//System.out.println(temp.endrange);
			//System.out.println(temp.Data);
			System.out.println();
	}

	
		public void deleteNode() 
		{
			if(head == null) 
			{
				System.out.println("No more sectors left");
			}
			else 
			{
				head = head.next;
				head.prev = tail;
				tail.next = head;
			}
	}
}
