package assignment1_20i2401;

import java.io.*;
import java.util.Scanner;



public class Files_function 
{
	String Directory_path="C:\\Users\\a\\Desktop\\Data Lab\\Assignment_1\\src\\assignment1_20i2401";
												//To create a new file
	public void createfile(String filename)
	{
		try
		{
			File obj= new File(filename);
			if(obj.createNewFile())
			{
				System.out.println("File created.");
				System.out.println("The name of file is  "+ obj.getName());
			}
			else
			{
				System.out.println("The files already exist");
			}
		}
		catch(IOException e)
		{
			System.out.println("Error occured");
			e.printStackTrace();
		}
	}
	
//	public void deleteFile(String input) {
//		File directory = new File(Directory_path);
//		MyFileNameFilter filter = new MyFileNameFilter(input);
//		String[] flist = directory.list(filter);
//		if (flist == null) {
//            System.out.println("Empty directory or directory does not exists.");
//        }
//        else {
//  
//          File fileToDelete;
//            for (int i = 0; i < flist.length; i++) {
//            	System.out.println(flist[i]+" found");
//            	
//            	for (String file : flist) {
//            		 
//                    //construct the absolute file paths...
//                    String absoluteFilePath = new StringBuffer(Directory_path).append(File.separator).append(file).toString();
//         
//                    //open the files using the absolute file path, and then delete them...
//                    fileToDelete = new File(absoluteFilePath);
//                    boolean isdeleted = fileToDelete.delete();
//                    System.out.println("File : " + absoluteFilePath + " was deleted : " + isdeleted);
//                }
//            	
//            }
//        }
//    }
	
	
	public void writeOnFile( String fileName, String input) throws IOException {
		BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));
		writer.write(input);
		System.out.println(input+" was Successfully written on "+fileName + "  file");
		writer.close();
	}
	
	public void readfile(String name)
	{
		try {
		      File myObj = new File(name);
		      Scanner myReader = new Scanner(myObj);
		      while (myReader.hasNextLine()) {
		        String data = myReader.nextLine();
		        System.out.println(data);
		      }
		      myReader.close();
		    } catch (FileNotFoundException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
	}
	
	
	public void filedelete(String filename)
	{
		File obj= new File(filename);
		boolean isdelete= obj.delete();
		if(isdelete)
		{
			 System.out.println("File  was deleted : " + isdelete);
			
		}
		else
		{
			System.out.println("file already exist");
		}
	}

}
