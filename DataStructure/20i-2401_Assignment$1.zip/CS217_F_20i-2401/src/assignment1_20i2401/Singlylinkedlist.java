package assignment1_20i2401;



public class Singlylinkedlist
{
	Nodefile head;
	public void InsertAtStart(String filename, int number )
	{
		Nodefile new_node= new Nodefile (filename, number);
		new_node.next= head;
		head= new_node;
	}
	
	public void InsertAtEnd(String filename, int number)
	{
		//Node last= new Node(data);
		Nodefile  last= new Nodefile(filename,number);
		if(this.head==null)
		{
			head= last;
		}
		else
		{
			Nodefile temp= head;
			while(temp.next!=null)
			{
				temp= temp.next;
			}
			temp.next= last;
		}
	}
	
	public void Display_Linkedlist()
	{
		Nodefile current= head;
		if(current==null)
		{
			System.out.println("The linked list is empty");
			return;
		}
		while(current!=null)
		{
			System.out.println(current.filename);
			System.out.println(current.NumberOfCharacter);
			current= current.next;
		}
		System.out.println();
	}
	
	public boolean file_existance(String filename)
	{
		boolean check = false;
		Nodefile newnode = head;
		while(newnode !=null  ) {
			if(newnode.filename.equals(filename)) {
				check = true;
			}
			newnode = newnode.next;
		}
		return check;
		
	}

}
