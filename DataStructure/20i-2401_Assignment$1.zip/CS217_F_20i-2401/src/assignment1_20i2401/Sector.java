package assignment1_20i2401;

public class Sector 
{
	int startrange;
	int endrange;
	Sector next;
	Sector prev;
	public Sector(int startrange, int endrange) 
	{
		
		this.startrange = startrange;
		this.endrange = endrange;
		this.next = null;
		this.prev = null;
	}
	

}
