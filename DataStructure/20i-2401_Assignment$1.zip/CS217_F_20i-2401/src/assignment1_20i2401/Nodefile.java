package assignment1_20i2401;

public class Nodefile 
{
	String filename;
	int NumberOfCharacter;
	Singlylinkedlist pool_next;
	Nodefile next;
	public Nodefile(String filename, int numberOfCharacter) 
	{
		
		this.filename = filename;
		NumberOfCharacter = numberOfCharacter;
		//this.pool_next=refer;
		next = null;
}
	
	

}
