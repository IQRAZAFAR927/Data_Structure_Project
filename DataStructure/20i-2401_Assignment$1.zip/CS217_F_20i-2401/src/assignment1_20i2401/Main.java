package assignment1_20i2401;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main 
{
	

	public static void main(String[] args) throws IOException 
	{
		ArrayList<String> arraylist= new ArrayList<String>();
		Function_class funobj= new Function_class();
		Files_function fileobj= new Files_function();
		Scanner input= new Scanner(System.in);
		System.out.println("------------Welcome to managing files------------\n");
		System.out.println("Enter the size of Sector: ");
		int size=input.nextInt();
		System.out.println("Enter the number of sector: ");
		int num= input.nextInt();
		int total_size= size*num;
		String[] Disk_array= new String [total_size];
		
		System.out.println("Enter your data: ");
		String data= input.next();
		
		System.out.println("Enter the file name: ");
		String file_name= input.next();
		fileobj.createfile(file_name);
		fileobj.writeOnFile(file_name, data);
		//fileobj.filedelete(file_name);
		
		
		//funobj.randomInsertion(num, size, Disk_array);
		funobj.divide_into_chunks(data,size,arraylist);
		String disk[]=funobj.addto_disk(Disk_array, arraylist);
		
		System.out.println("---------Chunks of files ---------------");
		funobj.display(disk);
		
		System.out.println("\nChunks of data on random index of disk\n");
		int min=0;
		 int max=Disk_array.length-1;
		 for(int i=0; i<data.length();i=i+size)
		 {
		 int random_int = (int)Math.floor(Math.random()*(max-min+1)+min);
		 System.out.print(random_int+ " ");
		 }
		 System.out.println();
		Singlylinkedlist list= new Singlylinkedlist();
		System.out.println("----------Data saved in singlylinkedlist-----------");
		System.out.println("File name and numberofcharacters");
		list.InsertAtStart(file_name,data.length());
		list.Display_Linkedlist();
		
//		System.out.println("------------Doubly linked list-------------");
//		Pool_linkedlist obj=new Pool_linkedlist();
		//obj.Insert_At_End(num, total_size);
		//funobj.Add_in_doublelinklist(obj, list, size, file_name);
		
		//obj.Insert_At_Start(size, num);
		//obj.Insert_At_Start(size, num);
		//obj.print_linkedlist();
				
		//String filename, int numberOfCharacter, Nodefile next
		
	
	}

	

}
