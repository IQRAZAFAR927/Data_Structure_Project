package assignment1_20i2401;

import java.util.ArrayList;
import java.util.Random;


public class Function_class 
{
	public  void divide_into_chunks( String data, int size, ArrayList<String> arraylist)
	{
		int temporary= size;
		int var=0;
		String Sub_String;
		int i=0;
		while(i<data.length())
		{
			Sub_String=data.substring(i, temporary);
			arraylist.add(Sub_String);
			
			var=data.length()-temporary;
			if(var>size)
			{
				temporary= temporary+size;
			}
			else
			{
				temporary=temporary+var;
				
			}
			if(temporary>data.length())
			{
				break;
			}
			i=i+size;
		}
	}
		public String[] addto_disk(String[] Disk_array,ArrayList<String> arraylist)
		{
			int y;
			int k=0;
			for(y=0;y<Disk_array.length;y++)
			{
				if(Disk_array[y]==null)
				{

					Disk_array[y]=arraylist.get(k);
					//System.out.print(y+ " ");
//					Pool_linkedlist obj= new Pool_linkedlist();
//					obj.Insert_At_Start(y, y+);
					k++;
				}
				
			
				if(k==arraylist.size())
				{
					break;
				}
				
			}
			//Pool_linkedlist obj= new Pool_linkedlist();
		//	obj.Insert_At_Start(0, y);
			return Disk_array;
		}
	
	
		public void display(String[]disk)
		{
			
			for(int j=0;j<disk.length;j++)
			{
				if(disk[j]!=null)
				{
					
					System.out.println(disk[j]);
				}
			}
		}
	
		
		
		 
		 
//		 public void randomInsertion(int numOfSector, int sizeOfSector, String array[]) 
//		{
//			 
//			 int[] run= new int[max];
//			 System.out.println("Random value in int from "+min+" to "+max+ ":");
//				
//				  		for(int j=0;j<array.length;j++)
//						 {
//				  			for(int i=0;i<run.length;i++)
//						  	{
//				  				
//				  				int k=0;
//				  				
//				  				while(random_int!=run[k] && k<run.length-1)
//				  				{
//				  					k++;
//				  					
//				  				}
//				  				array[random_int]=" ";
//				  				if(random_int==run[k])
//				  				{
//				  					break;
//				  				}
//				  								  		
//						  	}
//				 
//						 }
		    
//				int var = numOfSector*sizeOfSector;
//				Random rand = new Random();
//				
//				for(int i = 0; i< var; i++) 
//				{
//					array[i] = " ";
//				}
//				
//				for(int i = 0; i< var; i = i+ 4) {
//					
//					array[i] = "zzz";   
//					
//				}
				
			//}
		 public void Add_in_doublelinklist(Pool_linkedlist sector, Singlylinkedlist node, int sizeofsector,String filename)
		 {
			 if(node.file_existance(filename)==true)
			 {
				 int temp= node.head.NumberOfCharacter/sizeofsector;
				 for(int i=0; i<temp;i++)
				 {
					 sector.Insert_At_End(sizeofsector, i);
				 }
			 }
			 else
			 {
				 System.out.println("No such linked list of file exist");
			 }
		 }
		 
		 
			
	

}
