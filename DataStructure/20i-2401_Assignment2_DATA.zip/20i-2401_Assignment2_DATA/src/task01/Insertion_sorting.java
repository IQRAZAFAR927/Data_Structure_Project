package task01;

import java.util.Scanner;

public class Insertion_sorting 
{
	Stack head;
	
		public boolean isEmpty()
		{
			if(head==null)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	
		public void push(int new_data)
		{
			Stack newNode= new Stack(new_data);
			if(head==null)
			{
				head=newNode;
			}
			else
			{
				newNode.next=head;
				head=newNode;
			}
			
		}
		public void print()
		{
			Stack current=head;
			if(head==null)
			{
				System.out.println("[]");
			}
			else
			{
				System.out.print("[");
				while(current!=null)
				{
					System.out.print(current.data+ " ");
					current= current.next;
				}
				System.out.println("]");
			}
			
		}
		public int pop()
		{
			int pop=0;
			if(head==null)
			{
				return 0;
				
			}
			else
			{
				pop=(int) head.data;
				head= head.next;
			}
			return pop;
		}
	
		public int peek()
		{
			if(head==null)
			{
				System.out.println("Stack is empty");
				return -1;
			}
			else
			{
				return (int) head.data;
			}
			
		}
		
	public static  Insertion_sorting insertion(Insertion_sorting input_stack)
	{
		int temp=0;
		Insertion_sorting temp_stack= new Insertion_sorting();
		if(!(input_stack.isEmpty()))
		{
			while(!(input_stack.isEmpty()))				//Run the program until input stack was not empty
			{
				temp=input_stack.pop();					//Pop the element from input stack
				while( (!(temp_stack.isEmpty()) ) && temp>temp_stack.peek())			//Run until temporary stack  was not empty 
				{																		//peek of input stack was greater than temp peek
						
						int value=temp_stack.pop();							//Take peek of temp stack and push back in inout stack
						input_stack.push(value);
				}
				temp_stack.push(temp);	
			}
		}
		return temp_stack;
	}
	public void fast_cal(String input)
	{
		Scanner sc = new Scanner(System.in);
		Insertion_sorting obj= new Insertion_sorting();
		for(String temp: input.split(" "))
		{
			if(temp.equals("+") || temp.equals("*") || temp.equals("-") || temp.equals("/") || temp.equals("%")
					|| temp.equals("?") || temp.equals("!") || temp.equals("^")) 
			{
				if(temp.equals("+"))
				{
						int x= obj.pop();
				        int y = obj.pop();
				        if(x==0)
				        {
				        		obj.push(y);
				        		System.out.println("No enough arguments");
				        }
				        else if(y==0)
				        {
				        	obj.push(x);
			        		System.out.println("No enough arguments");
				        }
				        else
				        {
				        int r=x+y;
				        obj.push(x+y);
				        }       
				}
				else if(temp.equals("*"))
				{
					int	x = obj.pop();
			        int y = obj.pop();
			       int  r = x*y;
			        obj.push(r);
				}
				else if(temp.equals("/"))
				{
					int	x = obj.pop();
			        int y = obj.pop();
			       int  r = x/y;
			        obj.push(r);
				}
				else if(temp.equals("-"))
				{
					int	x = obj.pop();
			        int y = obj.pop();
			       int  r = x-y;
			        obj.push(r);
				}
				else if(temp.equals("%"))
				{
					int	x = obj.pop();
			        int y = obj.pop();
			       int  r = x%y;
			        obj.push(r);
				}
				else if(temp.equals("?"))
				{
			        obj.print();
				}
				else if(temp.equals("^"))
				{
					int p=obj.pop();
					System.out.println(p);
			       // obj.print();
				}
				else if(temp.equals("!"))
				{
					System.out.println("Bye Bye tata");
					System.exit(1);
				}
			}
			else
			{
				try
				{
				int j= 	Integer.parseInt(temp);
				obj.push(j);
				}
				catch(Exception e)
				{
					System.out.println("# Invalid input");
				}
			}	
		}			
	}
	
	public void RPN_CALCULATOR()
	{
	System.out.println("\n------WELCOME TO RPN CALCULATOR---------");
	System.out.println("YOU CAN ONLY ENTER INTEGER AND OPERATOR");
	System.out.println("? TO PRINT");
	System.out.println("^ TO POP");
	System.out.println("! TO QUIT");
	System.out.println("\n Enter your input");
	Scanner sc = new Scanner(System.in);
	Insertion_sorting obj= new Insertion_sorting();
	String temp = " ";
	while( (!(temp.equals("!")) ) )
	{
	    temp=sc.next();
		if(temp.equals("+") || temp.equals("*") || temp.equals("-") || temp.equals("/") || temp.equals("%")
				|| temp.equals("?") || temp.equals("!") || temp.equals("^") || temp.equals(" ")) 
		{
			if(temp.equals("+"))
			{
				int x= obj.pop();
		        int y = obj.pop();
		        if(x==0)
		        {
		        		obj.push(y);
		        		System.out.println("No enough arguments");
		        }
		        else if(y==0)
		        {
		        	obj.push(x);
	        		System.out.println("No enough arguments");
		        }
		        else
		        {
		        int r=x+y;
		        obj.push(x+y);
		        }  
			}
			else if(temp.equals("*"))
			{
				int	x = obj.pop();
		        int y = obj.pop();
		        if(x==0)
		        {
		        	obj.push(y);
	        		System.out.println("No enough arguments");
		        }
		        else if(y==0)
		        {
			        	obj.push(x);
		        		System.out.println("No enough arguments");
		        }
		        else
		        {
				       int  r = x*y;
				       obj.push(r);
		        }
			}
			else if(temp.equals("/"))
			{
				int	x = obj.pop();
		        int y = obj.pop();
		        if(x==0)
		        {
		        		obj.push(y);
		        		System.out.println("No enough arguments");
		        }
		        else if(y==0)
		        {
		        	obj.push(x);
	        		System.out.println("No enough arguments");
		        }
		        else
		        {
			       int  r = x/y;
			        obj.push(r);
		        }
			}
			else if(temp.equals("-"))
			{
				int	x = obj.pop();
		        int y = obj.pop();
		        if(x==0)
		        {
		        		obj.push(y);
		        		System.out.println("No enough arguments");
		        }
		        else if(y==0)
		        {
		        	obj.push(x);
	        		System.out.println("No enough arguments");
		        }
		        else
		        {
			       int  r = x-y;
			        obj.push(r);
		        }
			}
			else if(temp.equals("%"))
			{
				int	x = obj.pop();
		        int y = obj.pop();
		        if(x==0)
		        {
		        		obj.push(y);
		        		System.out.println("No enough arguments");
		        }
		        else if(y==0)
		        {
		        	obj.push(x);
	        		System.out.println("No enough arguments");
		        }
		        else
		        {
		        int  r = x%y;
		        obj.push(r);
		        }
			}
			else if(temp.equals("?"))
			{
		        obj.print();
			}
			else if(temp.equals("^"))
			{
				int p=obj.pop();
				System.out.println(p);
			}
			else if(temp.equals("!"))
			{
				System.out.println("Bye Bye tata");
			}
			else if(temp.equals(" "))
			{
				continue;
			}
		}
		else
		{
			try
			{
			int j= 	Integer.parseInt(temp);
			obj.push(j);
			}
			catch(Exception e)
			{
				System.out.println("# Invalid input");
			}
		}	
	 }	
   }
}
