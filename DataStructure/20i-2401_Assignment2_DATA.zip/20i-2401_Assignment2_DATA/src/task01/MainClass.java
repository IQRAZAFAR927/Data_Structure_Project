package task01;

import java.util.Scanner;



public class MainClass 
{
	
	public static void main(String[] args) 
	{
		Scanner input= new Scanner(System.in);
		int option = 0;
		Insertion_sorting input_stack= new Insertion_sorting();
		System.out.println("\tWELCOME TO PROGRAM");
		System.out.println("1- Modification Insertion Sorting Alogorithm");
		System.out.println("2- Slowed RPN-CALCULATOR");
		System.out.println("3- Fast RPN-CALCULATOR");
		System.out.println("4- End the program");
		System.out.println("Select your choice");
		int choice= input.nextInt();
		if(choice==1)
		{
			
			System.out.println("\n");
			do
			{
				
			System.out.println("-------------Enter the size of stack------------");
			int size= input.nextInt();
			for(int i=0; i<size;i++)
			{
				int t=i+1;
				System.out.println("Enter the "+ t + " number: ");
				int num=input.nextInt();
				input_stack.push(num);
			}
			System.out.println("-----------Before Sorting-----------");
			input_stack.print();
			Insertion_sorting obj= new Insertion_sorting();
			input_stack=obj.insertion(input_stack);
			System.out.println("\n-----------After Sorting----------------");
//			while(!(input_stack.isEmpty()))
//			{
//				System.out.println(input_stack.peek());
//				input_stack.pop();
//			}
			input_stack.print();
				System.out.println();
			System.out.println("Do You want to run this program again?\n1-YES\n2-NO");
			System.out.println("Enter your choice:");
			option=input.nextInt();
			if(option==1)
			{
				
			}
			else if(option==2)
			{
				main(args);
			}
			else
			{
				System.out.println("Invalid input");
			}
			}while(option==1);
			
		}
		else if(choice==2)
		{
			do
			{
			Insertion_sorting obj2= new Insertion_sorting();
			obj2.RPN_CALCULATOR();
			System.out.println("Do You want to run this program again?\n1-YES\n2-NO");
			System.out.println("Enter your choice:");
			option=input.nextInt();
			if(option==1)
			{
				
			}
			
			else if(option==2)
			{
				main(args);
			}
			else
			{
				System.out.println("Invalid input");
			}
			}while(option==1);
		
		}
		else if(choice==3)
		{
			do
			{
			Insertion_sorting obj2= new Insertion_sorting();
			obj2.RPN_CALCULATOR();
			System.out.println("Do You want to run this program again?\n1-YES\n2-NO");
			System.out.println("Enter your choice:");
			option=input.nextInt();
			if(option==1)
			{
				
			}
			else if(option==2)
			{
				main(args);
			}
			else
			{
				System.out.println("Invalid input");
			}
			}while(option==1);
		}
		else if(choice==4)
		{
			System.out.println("\n\n-----------PROGRAM ENDED--------------");
			System.exit(1);
		}
		
		
		
		
		//String temp = "";
		//System.out.println("enter");
		//temp=input.nextLine();
		//"? 10 ? 20 30 ? * + ? ^ ? !"
		//System.out.println("ballll");
	//	obj2.fast_cal(temp);
		
		

	}
}

	


