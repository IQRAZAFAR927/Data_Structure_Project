package task01;

public class Stack 
{
	int data;
	Stack next;
	
	public Stack(int data) 
	{
		
		this.data = data;
		this.next = null;
	}
}
