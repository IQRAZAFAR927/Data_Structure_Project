package assignment3;

import java.io.IOException;
import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) throws IOException 
	{
		Scanner input= new Scanner(System.in);
		Scanner sc= new Scanner(System.in);
		Filehandling fileobj= new Filehandling();
		BSTSearchTree treeobj= new BSTSearchTree();
		int option;
		String word;
		String del;
		int choice;
		int count=0;
		String w="";
		fileobj.clear("insert.txt");
		fileobj.clear("inorder.txt");
		fileobj.clear("postorder.txt");
		fileobj.clear("preorder.txt");
		System.out.println("\t\t------------------------------------------------");
		System.out.println("\t\t|            WELCOME TO PROGRAM                 |");
		System.out.println("\t\t------------------------------------------------");
		
		System.out.println("Please Selects the option:");
		do
		{
				System.out.println("1-    Insertion");
				System.out.println("2-    Deletion");
				System.out.println("3-    Traversal");
				System.out.println("4-    All Orders");
				System.out.println("5-    Exit");
				option=input.nextInt();
				if(option==1)
				{
					System.out.println("Enter the word:");
					word= sc.nextLine();
					treeobj.insert(word);
					//fileobj.clear("insert.txt");
					fileobj.writing_files("insert.txt",word);
					//treeobj.insert(word);
	//				fileobj.filereading("insert.txt");
	//				char[] array= fileobj.fromFile.toCharArray();
	//				for(char a: array) 
	//				{
	//					 w = w + a;
	//					 if(a ==' ' || count == word.length() )
	//					 {
	//						treeobj.insert(w);
	//						System.out.println(w);
	//						 w = " ";
	//					 }
	//					 count++;
	//					 
	//				}
					
					
					//treeobj.display();
				}
				else if(option==2)
				{
					System.out.print("Enter the word you want to delete: ");
					del=input.next();
					treeobj.delete(del);
					fileobj.clear("insert.txt");
					fileobj.writing_files("insert.txt", treeobj.inorder);
					//fileobj.update_data(del, "insert.txt");
					System.out.println("Please Select the option: ");
					System.out.println("1-  Inorder");
					System.out.println("2-  Postorder");
					System.out.println("3-  Preorder");
					System.out.println("4- All Orders");
					choice= input.nextInt();
						if(choice==1)
						{
							System.out.println("---------On Terminal-------");
							fileobj.clear("inorder.txt");
							treeobj.inorder();
							fileobj.writing_files("inorder.txt",  treeobj.inorder);	
						}
						else if(choice==2)
						{
							System.out.println("---------On Terminal-------");
							fileobj.clear("postorder.txt");
							treeobj.postorder();
							fileobj.writing_files("postorder.txt", treeobj.postorder);
						}
						else if(choice==3)
						{
							System.out.println("---------On Terminal-------");
							fileobj.clear("preorder.txt");
							treeobj.preorder();	
							fileobj.writing_files("preorder.txt",treeobj.preorder);
						}
						else if(choice==4)
						{
							System.out.println("---------On Terminal-------");
							treeobj.display();
							fileobj.clear("inorder.txt");
							fileobj.clear("postorder.txt");
							fileobj.clear("preorder.txt");
							fileobj.writing_files("postorder.txt", treeobj.postorder);
							fileobj.writing_files("inorder.txt",  treeobj.inorder);
							fileobj.writing_files("preorder.txt",treeobj.preorder);
						}
						else 
						{
							System.out.println("Invalid option");
						}
						
				}
				else if(option==3)
				{
					System.out.println("Please Select the option: ");
					System.out.println("1-  Inorder");
					System.out.println("2-  Postorder");
					System.out.println("3-  Preorder");
					System.out.println("4- All Orders");
					choice= input.nextInt();
						if(choice==1)
						{
							fileobj.clear("inorder.txt");
							treeobj.inorder();
							fileobj.writing_files("inorder.txt",  treeobj.inorder);
						}
						else if(choice==2)
						{
							fileobj.clear("postorder.txt");
							treeobj.postorder();
							fileobj.writing_files("postorder.txt", treeobj.postorder);
						}
						else if(choice==3)
						{
							fileobj.clear("preorder.txt");
							treeobj.preorder();
							fileobj.writing_files("preorder.txt",treeobj.preorder);
						}
						else if(choice==4)
						{
							System.out.println("---------On Terminal-------");
							treeobj.display();
							fileobj.clear("inorder.txt");
							fileobj.clear("postorder.txt");
							fileobj.clear("preorder.txt");
							fileobj.writing_files("postorder.txt", treeobj.postorder);
							fileobj.writing_files("inorder.txt",  treeobj.inorder);
							fileobj.writing_files("preorder.txt",treeobj.preorder);
						}
						else 
						{
							System.out.println("Invalid option");
						}
				}
				else if(option==4)
				{
					System.out.println("---------On Terminal-------");
					treeobj.display();
					fileobj.clear("inorder.txt");
					fileobj.clear("postorder.txt");
					fileobj.clear("preorder.txt");
					fileobj.writing_files("postorder.txt", treeobj.postorder);
					fileobj.writing_files("inorder.txt",  treeobj.inorder);
					fileobj.writing_files("preorder.txt",treeobj.preorder);
				}
				else if(option==5)
				{
					System.exit(1);
					System.out.println("\t\tEND THE PROGRAM");
				}
				else 
				{
					System.out.println("Inavlid option");
				}
			}while(option!=5);
		
		
		
	

	}

}
