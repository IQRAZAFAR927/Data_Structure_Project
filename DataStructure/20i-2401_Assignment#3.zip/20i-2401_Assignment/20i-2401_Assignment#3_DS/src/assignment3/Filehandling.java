package assignment3;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;

public class Filehandling 
{
	static int index_check=0;
	public void create_file(String file_name) {
	try 
	{
		File file=new File(file_name);
		if(file.createNewFile())
		{
			System.out.println(" File '"+file.getName()+"' Is Created ");
		}
		else
		{
			System.out.println(" File Is Already Exist");
		}
	} 
	catch (IOException i)
	{
	     System.err.println(" Error Found");
         i.printStackTrace();
	}
}
	public void writing_files(String path,String data)
	{
		try 
		{
			FileWriter f_write=new FileWriter(path,true);
			
			f_write.write(data+ "\n");
			f_write.close();
		}
         catch(IOException i) 
		{
		     System.out.println(" Error Found");
		     i.printStackTrace();
	    }
	

	}
	String fromFile=" ";
	public void filereading(String path) throws IOException
	{
		BufferedReader br= new BufferedReader(new FileReader(path));

    
    String st;
    while ((st = br.readLine()) != null)
    {

    	fromFile = fromFile + st;
        // Print the string
    	
    // System.out.print(st+ " ");
	
	}
  }
	public void clear(String name) throws FileNotFoundException
	{
		PrintWriter writer = new PrintWriter(name);
		writer.print("");
		writer.close();
	}
	
	
	
	public void update_data(String word,String path) throws FileNotFoundException
	{
		// String filePath = path;
		 String result = fileToString(path);
	     // System.out.println("Contents of the file: "+result);
	      //Replacing the word with desired one
	      result = result.replaceAll(word, "");
	      //Rewriting the contents of the file
	      PrintWriter writer = new PrintWriter(new File(path));
	      writer.append(result);
	      writer.flush();
	   //   System.out.println("Contents of the file after replacing the desired word:");
	     // System.out.println(fileToString(filePath));
	}
//	
//	public void delete_data(String filepath)
//    {
//		PrintWriter writer = new PrintWriter(FILE_PATH);
//		writer.print("");
//		// other operations
//		writer.close();
//    }
	private String fileToString(String filePath) {
		// TODO Auto-generated method stub
		return null;
	}
}

