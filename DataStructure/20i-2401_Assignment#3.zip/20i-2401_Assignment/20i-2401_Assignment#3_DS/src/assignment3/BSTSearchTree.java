package assignment3;

import java.io.FileNotFoundException;


public class BSTSearchTree 
{
	BSTNodeClass root;
	String postorder="";
	String preorder="";
	String inorder="";
	Filehandling obj = new Filehandling();

	public BSTSearchTree()
	{
		
		this.root = null;
	}
	public void insert(String word)
	{
		root=recursion_insertion(root, word);
	}

	
	BSTNodeClass recursion_insertion(BSTNodeClass root, String word)
	{
		BSTNodeClass newnode= new BSTNodeClass(word);
		if(root==null)
		{
			root= newnode;
			return root;
		}
		else
		{
			if(word.compareTo(root.data)>0)
			{
				root.right= recursion_insertion(root.right,word);
			}
			else if(word.compareTo(root.data)<0)
			{
				root.left= recursion_insertion(root.left,word);
			}
			return root;	
		}
		
	}
	
	public void delete(String word)
	{
		root=recursion_deletion(root, word);
	}
	
	BSTNodeClass recursion_deletion(BSTNodeClass root, String word)
	{
		
		if(root==null)
		{
			return root;
		}
		if(word.compareTo(root.data)>0)
		{
			root.right= recursion_deletion(root.right,word);
		}
		else if(word.compareTo(root.data)<0)
		{
			root.left=recursion_deletion(root.left,word);
		}
		else 
		{
			if(root.left==null)
			{
				return root.right;
			}
			else if(root.right==null)
			{
				return root.left;
			}
			else 
			{
				// Move one node to the right.
				BSTNodeClass temp = root.right;
				// Go to the extreme left node.
				while (temp.left!=null)
				temp = temp.left;
				// Reattach the left subtree.
				temp.left = root.left;
				// Reattach the right subtree.
				root = root.right;

				return root;
			}
		}
				//root=root.right;
//				while(root.left!=null)
//				{
//					root=root.left;
//				}
		return root;
				
		
		
	}
	
	 public String minValue(BSTNodeClass root)
	    {
	       String min=root.data;
	        while (root.left != null)
	        {
	            min = root.left.data;
	            root = root.left;
	        }
	        return min;
	    }
	
	public void inorder(BSTNodeClass temp)	
	{
		if (temp!=null)
		{
			inorder(temp.left);
			inorder= inorder+temp.data;
			inorder=inorder+"\n";
			System.out.println(temp.data+ " ");
			inorder(temp.right);
		}
	}
	
	public void inorder()
	{
	
		inorder(this.root);	
	}
	public void preorder(BSTNodeClass temp)
	{
		if (temp!=null)
		{
			preorder = preorder + temp.data;
			preorder = preorder + "\n";
			System.out.println(temp.data + " ");
			preorder(temp.left);
			preorder(temp.right);		
		
		}
	}
	
	public void preorder()
	{
		
		preorder(this.root);
	}
	public void postorder(BSTNodeClass temp)
	{
		if (temp!=null)
		{
			postorder(temp.left);
			postorder(temp.right);
			postorder= postorder+ temp.data;
			postorder= postorder+ "\n";
			System.out.println(temp.data+ " ");
			
		
		}
	}
	public void postorder()
	{
	
		postorder(this.root);
	}
	
	public void display()
	{
		System.out.println("--------------IN-ORDER------------");
		inorder();
		System.out.println("\n");
	
		System.out.println("--------------PRE-ORDER-----------");
		System.out.println();
		preorder();
		System.out.println("\n");		
		
		System.out.println("-------------POST-ORDER------------");
		System.out.println();
		postorder();
		System.out.println("\n");
		
	}

	
}
