package assignment3;

public class BSTNodeClass 
{
	String data;
	BSTNodeClass left;
	BSTNodeClass right;
	public BSTNodeClass(String data) {
		
		this.data = data;
		this.left = null;
		this.right = null;
	}
	
	public BSTNodeClass()
	{
		
	}
	
	

}
